<?php
/** CYBRON — War Room (Hardened & Optimized) */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_active();
$me = current_user();

// Handle Flash Messages
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Form Handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        die('Invalid CSRF token.');
    }

    $action = $_POST['do'] ?? '';

    // Action: Board Creation
    if ($action === 'board') {
        $t = trim($_POST['title'] ?? '');
        $kind = in_array($_POST['kind'] ?? '', ['campaign','policy','threat','general'], true) ? $_POST['kind'] : 'general';
        $desc = trim($_POST['description'] ?? '');

        if ($t === '' || strlen($t) > 100) {
            $_SESSION['flash'] = 'Error: Invalid Title length.';
        } else {
            $stmt = db()->prepare('INSERT INTO warroom_boards (title, kind, description, created_by) VALUES (?,?,?,?)');
            $stmt->execute([$t, $kind, $desc, $me['id']]);
            audit('board_create', $t);
            $_SESSION['flash'] = 'Board created successfully.';
        }
    } 
    // Action: Threat Intel Reporting
    elseif ($action === 'threat') {
        $t = trim($_POST['title'] ?? '');
        $cat = trim($_POST['category'] ?? '');
        $summary = trim($_POST['summary'] ?? '');
        $region = trim($_POST['region'] ?? '');
        $sev = in_array($_POST['severity'] ?? '', ['low','medium','high','critical'], true) ? $_POST['severity'] : 'medium';

        if ($t === '' || strlen($t) > 100 || strlen($summary) > 1000) {
            $_SESSION['flash'] = 'Error: Invalid input lengths.';
        } else {
            $stmt = db()->prepare('INSERT INTO threat_intel (title, category, summary, region, severity, reported_by) VALUES (?,?,?,?,?,?)');
            $stmt->execute([$t, $cat, $summary, $region, $sev, $me['id']]);
            audit('threat_add', $t);
            $_SESSION['flash'] = 'Intel reported to the feed.';
        }
    }
    
    redirect(BASE_URL . '/warroom.php');
}

// Fetch Data
$boards = db()->query('SELECT b.*, u.name FROM warroom_boards b JOIN users u ON u.id=b.created_by ORDER BY b.created_at DESC')->fetchAll();
$threats = db()->query('SELECT t.*, u.name FROM threat_intel t LEFT JOIN users u ON u.id=t.reported_by ORDER BY t.created_at DESC LIMIT 30')->fetchAll();

$page_title = 'War Room';
require __DIR__ . '/includes/header.php';
?>

<section class="page">
  <div class="wrap">
    <div class="section-head" style="text-align:left">
      <span class="section-tag">[ WAR ROOM ]</span>
      <h2 style="font-size:28px">Plan the fight together</h2>
      <p>Campaigns, policy, and threat response — shared across NGOs, educators, police, banks and government.</p>
    </div>

    <?php if ($flash): ?>
        <div class="card" style="border:1px solid var(--cyan); margin-bottom:20px; padding:15px; color:var(--cyan)">
            <?= e($flash) ?>
        </div>
    <?php endif; ?>

    <div class="grid grid-2" style="align-items:start">
      <div>
        <h3 style="font-family:'Sora'">Planning boards</h3>
        <div class="grid" style="margin-top:14px">
          <?php foreach ($boards as $b): ?>
            <a class="card" href="<?= e(BASE_URL) ?>/board.php?id=<?= (int)$b['id'] ?>" style="text-decoration:none">
              <span class="pill pill-cyan"><?= e($b['kind']) ?></span>
              <h3 style="margin-top:8px"><?= e($b['title']) ?></h3>
              <p class="muted"><?= e($b['description'] ?: 'Open board →') ?></p>
            </a>
          <?php endforeach; ?>
          <?php if (!$boards): ?><p class="muted">No boards yet — create the first one.</p><?php endif; ?>
        </div>

        <form method="post" class="form-card" style="max-width:none;margin-top:18px">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="do" value="board">
          <h3 style="font-family:'Sora'">New board</h3>
          <label>TITLE</label><input name="title" required placeholder="e.g. Diwali UPI scam awareness" maxlength="100">
          <label>TYPE</label>
          <select name="kind">
            <option value="campaign">Campaign</option>
            <option value="policy">Policy</option>
            <option value="threat">Threat response</option>
            <option value="general">General</option>
          </select>
          <label>DESCRIPTION</label><textarea name="description" placeholder="What's this board for?" maxlength="500"></textarea>
          <button class="btn btn-primary btn-block" style="margin-top:14px">Create board</button>
        </form>
      </div>

      <div>
        <h3 style="font-family:'Sora'">Threat intel feed</h3>
        <div class="grid" style="margin-top:14px">
          <?php foreach ($threats as $t): ?>
            <div class="card">
              <span class="pill <?= in_array($t['severity'],['high','critical'])?'pill-red':($t['severity']=='medium'?'pill-amber':'pill-cyan') ?>"><?= e($t['severity']) ?></span>
              <h3 style="margin-top:8px;font-size:17px"><?= e($t['title']) ?></h3>
              <p class="muted"><?= e($t['summary']) ?></p>
              <p class="muted" style="font-size:12px;margin-top:6px"><?= e($t['region'] ?: 'India') ?> · <?= e($t['name'] ?? 'anon') ?></p>
            </div>
          <?php endforeach; ?>
          <?php if (!$threats): ?><p class="muted">No intel yet.</p><?php endif; ?>
        </div>

        <form method="post" class="form-card" style="max-width:none;margin-top:18px">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="do" value="threat">
          <h3 style="font-family:'Sora'">Report a new scam pattern</h3>
          <label>TITLE</label><input name="title" required placeholder="e.g. Fake electricity bill SMS" maxlength="100">
          <label>CATEGORY</label><input name="category" placeholder="phishing, UPI, OTP…" maxlength="50">
          <label>REGION</label><input name="region" placeholder="State / city" maxlength="50">
          <label>SEVERITY</label>
          <select name="severity">
            <option value="low">Low</option>
            <option value="medium" selected>Medium</option>
            <option value="high">High</option>
            <option value="critical">Critical</option>
          </select>
          <label>SUMMARY</label><textarea name="summary" required placeholder="How it works…" maxlength="1000"></textarea>
          <button class="btn btn-primary btn-block" style="margin-top:14px">Add to feed</button>
        </form>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>