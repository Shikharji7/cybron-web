<?php
/** CYBRON — AI Dynamic Threat Assessment Core */
declare(strict_types=1);

// Standard App Integrations
require_once __DIR__ . '/includes/functions.php';

// ==========================================
// BACKEND SHUFFLE ENGINE (No separate file needed!)
// ==========================================
function getDynamicThreatScenarios(): array {
    $masterPool = [
        ["q" => "You receive a WhatsApp message from your 'Electricity Board' threatening immediate disconnection unless you install an .APK file. Your action?", "a" => ["Download and install to check authenticity", "Report to 1930, block the contact, never install third-party APKs"], "c" => 1, "why" => "Government nodes or public utilities never distribute security configurations via untrusted APK packages."],
        ["q" => "An AI-generated voice of your college friend calls you frantically asking for emergency funds via UPI. What is the verification protocol?", "a" => ["Immediately transfer the money", "Hang up and call the friend via standard cellular voice call to verify identity"], "c" => 1, "why" => "AI Deepfake voice cloning scams are hyper-prevalent. Direct out-of-band verification is the primary defense."],
        ["q" => "While checking Cybron diagnostics, you find your browser has an unauthorized extension tracking clipboard data. This vector is:", "a" => ["A benign cookie management framework", "Malicious Spyware / Clipboard Hijacker"], "c" => 1, "why" => "Clipboard hijackers monitor copy-paste operations to swap crypto addresses or credentials dynamically."],
        ["q" => "A 'FedEx Courier' executive calls saying illegal narcotics were seized in a package under your Aadhaar card. They demand you stay on a Skype call:", "a" => ["Comply out of fear and initiate asset screening transfer", "Break connection immediately, acknowledge it as a Fake Customs Scam, report to National Cyber Crime Portal"], "c" => 1, "why" => "No enforcement directorate or customs department enforces continuous digital custody or financial escrow tracking over video calls."],
        ["q" => "An Instagram ad claims an investment portal gives 200% returns daily backed by Cybron's security shield. You:", "a" => ["Invest minor capital to check liquidity", "Isolate and report as a fraudulent high-yield investment scheme (Task Scam)"], "c" => 1, "why" => "Guaranteed astronomical yields backed by zero regulated commodities are signature setups for cyber financial fraud."]
    ];
    
    shuffle($masterPool);
    return array_slice($masterPool, 0, 5); 
}

$dynamicQuestions = getDynamicThreatScenarios();

$page_title = 'Awareness Assessment';
require __DIR__ . '/includes/header.php';
?>

<style>
    :root {
        --neon-cyan: #00ffc2;
        --neon-purple: #4facfe;
        --void-panel: #1a2235;
        --border-color: #313e5c;
        --text-muted: #7686a8;
        --danger: #ff4757;
        --success: #2ecc71;
    }
    
    .quiz-master-card {
        background: #1a2235;
        border: 1px solid var(--border-color);
        border-radius: 16px;
        padding: 32px;
        box-shadow: 0 12px 40px rgba(0,0,0,0.25);
        margin-top: 24px;
        position: relative;
    }

    .pill-matrix {
        padding: 6px 14px;
        border-radius: 30px;
        font-weight: 600;
        font-size: 13px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: #232d45;
        border: 1px solid var(--border-color);
    }

    .opt-btn-premium {
        display: block;
        width: 100%;
        text-align: left;
        padding: 16px 20px;
        margin: 12px 0;
        border: 2px solid var(--border-color);
        border-radius: 10px;
        background: transparent;
        color: #e8ecf1;
        font-size: 16px;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .opt-btn-premium:hover:not(:disabled) {
        border-color: var(--neon-cyan);
        background: rgba(0, 255, 194, 0.05);
        color: #fff;
    }

    .opt-btn-premium:disabled {
        cursor: not-allowed;
    }

    .feedback-panel {
        margin-top: 20px;
        padding: 16px;
        border-radius: 8px;
        font-size: 14px;
        line-height: 1.6;
    }

    .btn-action-core {
        padding: 12px 24px;
        border-radius: 30px;
        font-weight: 600;
        cursor: pointer;
        border: none;
        transition: 0.2s;
    }
</style>

<section class="page" style="padding: 40px 0;">
  <div class="wrap" style="max-width:680px">
    
    <div class="section-head" style="text-align:left; margin-bottom: 20px;">
      <span class="section-tag" style="color: var(--neon-cyan);">[ ENGINE v2.6 · DYNAMIC THREAT MATRIX ]</span>
      <h2 style="font-size:30px; color:#fff; font-weight:700; margin-top:5px;">Are you scam-proof?</h2>
      <p style="color: var(--text-muted);">Real-time systemic scenario analytics. Validate your incident response profile.</p>
    </div>

    <div class="row-between" style="margin-bottom:20px; display:flex; gap:12px; flex-wrap:wrap; align-items:center; justify-content:space-between;">
      <div style="display: flex; gap: 8px;">
        <span class="pill-matrix" style="color: var(--neon-cyan);" id="xpTracker">XP: 0</span>
        <span class="pill-matrix" style="color: #ffb300;" id="streakTracker">🔥 Streak: 0</span>
      </div>
      <div style="display: flex; gap: 10px;">
         <button id="abortBtn" class="btn-action-core" style="background: rgba(255,71,87,0.1); color: var(--danger); border: 1px solid rgba(255,71,87,0.2); padding: 6px 16px; font-size:13px;">✕ Stop Quiz</button>
         <button id="flushBtn" class="btn-action-core" style="background: transparent; color: var(--text-muted); border: 1px solid var(--border-color); padding: 6px 16px; font-size:13px;">⟳ Reset Pool</button>
      </div>
    </div>

    <div class="quiz-master-card" id="quizShell"></div>
    
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>

<script>
(function() {
    var SEED_DATA = <?php echo json_encode($dynamicQuestions); ?>;
    
    var currentPointer = 0;
    var sessionXP = parseInt(localStorage.getItem('cybron_xp') || '0', 10);
    var continuousStreak = parseInt(localStorage.getItem('cybron_streak') || '0', 10);
    var transactionStateAnswered = false;

    var container = document.getElementById('quizShell');
    var xpTracker = document.getElementById('xpTracker');
    var streakTracker = document.getElementById('streakTracker');
    var abortBtn = document.getElementById('abortBtn');
    var flushBtn = document.getElementById('flushBtn');

    function refreshDashVisuals() {
        xpTracker.textContent = 'XP: ' + sessionXP;
        streakTracker.textContent = '🔥 Streak: ' + continuousStreak;
    }

    function processDecision(userChoice) {
        if (transactionStateAnswered) return;
        transactionStateAnswered = true;

        var targetNode = SEED_DATA[currentPointer];
        var optionButtons = container.querySelectorAll('.opt-btn-premium');
        
        optionButtons.forEach(function(b) { b.disabled = true; });

        var assessmentPass = (userChoice === targetNode.c);
        if (assessmentPass) {
            sessionXP += 10;
            continuousStreak += 1;
        } else {
            continuousStreak = 0;
        }

        localStorage.setItem('cybron_xp', sessionXP.toString());
        localStorage.setItem('cybron_streak', continuousStreak.toString());
        refreshDashVisuals();

        optionButtons.forEach(function(btn, index) {
            if (index === targetNode.c) {
                btn.style.borderColor = '#2ecc71';
                btn.style.backgroundColor = 'rgba(46,204,113,0.12)';
                btn.style.color = '#2ecc71';
            } else if (index === userChoice && index !== targetNode.c) {
                btn.style.borderColor = '#ff4757';
                btn.style.backgroundColor = 'rgba(255,71,87,0.12)';
                btn.style.color = '#ff4757';
            }
        });

        var analysisBox = document.createElement('div');
        analysisBox.className = 'feedback-panel';
        analysisBox.style.background = assessmentPass ? 'rgba(46,204,113,0.06)' : 'rgba(255,71,87,0.06)';
        analysisBox.style.border = '1px solid ' + (assessmentPass ? 'rgba(46,204,113,0.2)' : 'rgba(255,71,87,0.2)');
        analysisBox.style.color = assessmentPass ? '#2ecc71' : '#ff6b6b';
        analysisBox.innerHTML = '<strong style="display:block; margin-bottom: 4px;">' + (assessmentPass ? '✓ ACCESS DEFENSED' : '🗙 PERIMETER BREACHED') + '</strong>' + targetNode.why;
        container.appendChild(analysisBox);

        var triggerNextBtn = document.createElement('button');
        triggerNextBtn.className = 'btn-action-core';
        triggerNextBtn.style.cssText = 'margin-top:20px; width:100%; background: #00ffc2; color:#0f1521; font-size:15px; font-weight:700;';
        triggerNextBtn.innerHTML = (currentPointer < SEED_DATA.length - 1) ? 'Next Threat Scenario →' : 'Finalize Audit Report 🏁';
        
        triggerNextBtn.addEventListener('click', function() {
            currentPointer++;
            evaluateRuntimeState();
        });
        container.appendChild(triggerNextBtn);
    }

    function evaluateRuntimeState() {
        transactionStateAnswered = false;
        container.innerHTML = '';

        if (currentPointer >= SEED_DATA.length) {
            container.innerHTML = '<div style="text-align:center; padding: 20px 0;">' +
                                  '<h3 style="font-size:22px; color:#fff; margin-bottom:8px;">Assessment Concluded</h3>' +
                                  '<p style="color:var(--text-muted)">Security Profile Updated. Session XP integration complete.</p>' +
                                  '</div>';
            return;
        }

        var activePayload = SEED_DATA[currentPointer];
        
        var queryElement = document.createElement('h3');
        queryElement.style.cssText = 'font-size:18px; margin-bottom:20px; color:#fff; font-weight:600; line-height:1.5;';
        queryElement.textContent = activePayload.q;
        container.appendChild(queryElement);

        activePayload.a.forEach(function(optionString, idx) {
            var actionBtn = document.createElement('button');
            actionBtn.type = 'button';
            actionBtn.className = 'opt-btn-premium';
            actionBtn.textContent = (idx === 0 ? 'A. ' : 'B. ') + optionString;
            
            actionBtn.addEventListener('click', function() {
                processDecision(idx);
            });
            container.appendChild(actionBtn);
        });
    }

    abortBtn.addEventListener('click', function() {
        if(confirm('Are you sure you want to stop the current assessment tracking session?')) {
            container.innerHTML = '<div style="text-align:center; padding:20px 0; color:#ff4757;">' +
                                  '<h3>⚠️ Operational Assessment Aborted</h3>' +
                                  '<p style="color:#7686a8; margin-top:8px;">Tactical metrics secured. Total XP preserved: ' + sessionXP + '</p>' +
                                  '</div>';
            transactionStateAnswered = true;
        }
    });

    flushBtn.addEventListener('click', function() {
        if(confirm('Flush persistent profiling matrices?')) {
            localStorage.setItem('cybron_xp', '0');
            localStorage.setItem('cybron_streak', '0');
            window.location.reload();
        }
    });

    refreshDashVisuals();
    evaluateRuntimeState();
})();
</script>