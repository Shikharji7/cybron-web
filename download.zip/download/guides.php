<?php
/** CYBRON — safety guides */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Safety guides';
require __DIR__ . '/includes/header.php';
$guides = [
  ['🔐','Secure your UPI','Never enter a UPI PIN to receive money. Set app locks. Disable auto-pay you do not recognise.'],
  ['📵','Handle scam calls','Banks never ask for OTP/PIN/CVV. Hang up, call the official number on your card, never a number from the caller.'],
  ['💳','Card safety','Mask CVV, enable transaction alerts, set low online limits, and use virtual cards for new sites.'],
  ['🔗','Check links','Hover before tapping. Beware shortened links and look-alike domains (paytmm, sbi-kyc). Use the Scam check tool.'],
  ['📱','Phone hygiene','Lock SIM with a PIN, avoid unknown APKs, keep OS updated, review app permissions monthly.'],
  ['⏱️','Golden hour','If money is gone, call 1930 within the first hour — funds can often be frozen before they move out.'],
];
?>
<section class="page"><div class="wrap">
  <div class="section-head" style="text-align:left">
    <span class="section-tag">[ SAFETY GUIDES ]</span>
    <h2 style="font-size:28px">Stay a step ahead</h2>
    <p>Quick, practical habits that stop most frauds. Switch language anytime.</p>
  </div>
  <div class="grid grid-3">
    <?php foreach ($guides as $g): ?>
      <div class="card"><div class="icon"><?= $g[0] ?></div><h3><?= e($g[1]) ?></h3><p class="muted"><?= e($g[2]) ?></p></div>
    <?php endforeach; ?>
  </div>
  <div class="card" style="margin-top:18px;text-align:center">
    <h3>📺 Watch & learn</h3>
    <p class="muted" style="margin:8px 0 14px">More safety content on our channels.</p>
    <a href="<?= e(SOCIAL['youtube']) ?>" target="_blank" rel="noopener" class="btn btn-primary">YouTube</a>
    <a href="<?= e(BASE_URL) ?>/quiz.php" class="btn btn-ghost">Take the quiz</a>
  </div>
</div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
