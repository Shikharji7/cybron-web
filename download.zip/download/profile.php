<?php
/** CYBRON — User Profile (Hardened & Optimized) */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_active();
$me = current_user();

// Handle Flash Messages
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Form Handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        die('Invalid security token.');
    }

    $action = $_POST['do'] ?? '';

    // Action: Update Profile Details
    if ($action === 'update_profile') {
        $name = trim($_POST['name'] ?? '');
        $org = trim($_POST['organisation'] ?? '');
        
        // Backend Validation
        if ($name === '' || strlen($name) > 100 || strlen($org) > 100) {
            $_SESSION['flash'] = 'Error: Invalid input length.';
        } else {
            $stmt = db()->prepare('UPDATE users SET name=?, organisation=? WHERE id=?');
            $stmt->execute([$name, $org, $me['id']]);
            audit('profile_update', 'User updated profile details');
            $_SESSION['flash'] = 'Profile updated successfully.';
        }
    }

    // Action: Request Verification
    if ($action === 'request_verification' && $me['verification_status'] === 'unverified') {
        // Prevent double insertion
        $stmt = db()->prepare('INSERT INTO verification_requests (user_id, role, status) VALUES (?,?,?)');
        $stmt->execute([$me['id'], $me['role'], 'pending']);
        
        db()->prepare('UPDATE users SET verification_status=? WHERE id=?')->execute(['pending', $me['id']]);
        audit('verification_request', 'User requested verification');
        $_SESSION['flash'] = 'Verification request sent to admin.';
    }

    redirect(BASE_URL . '/profile.php');
}

$page_title = 'My Profile';
require __DIR__ . '/includes/header.php';
?>
<section class="page">
  <div class="wrap" style="max-width:600px">
    <div class="section-head">
      <span class="section-tag">[ ACCOUNT ]</span>
      <h2 style="font-size:28px">Manage Profile</h2>
    </div>

    <?php if ($flash): ?>
        <div class="card" style="border:1px solid var(--cyan); margin-bottom:20px; padding:15px; color:var(--cyan)">
            <?= e($flash) ?>
        </div>
    <?php endif; ?>

    <div class="card">
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="do" value="update_profile">
        
        <label>FULL NAME</label>
        <input name="name" value="<?= e($me['name']) ?>" required maxlength="100">
        
        <label>ORGANISATION (Optional)</label>
        <input name="organisation" value="<?= e($me['organisation'] ?? '') ?>" placeholder="Company, College, or NGO" maxlength="100">
        
        <button class="btn btn-primary" style="margin-top:14px">Save Changes</button>
      </form>
    </div>

    <div class="card" style="margin-top:16px">
      <h3>Verification Status</h3>
      <p class="muted" style="margin-bottom:14px">Current Status: <strong><?= e(ucfirst($me['verification_status'])) ?></strong></p>
      
      <?php if ($me['verification_status'] === 'unverified'): ?>
        <form method="post">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="do" value="request_verification">
          <button class="btn btn-ghost btn-block">Request Verification</button>
        </form>
      <?php elseif ($me['verification_status'] === 'pending'): ?>
        <p class="pill pill-amber">Verification is under review by admin.</p>
      <?php elseif ($me['verification_status'] === 'active'): ?>
        <p class="pill pill-cyan">Your account is fully verified.</p>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>