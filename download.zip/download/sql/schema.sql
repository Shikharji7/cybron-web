-- ============================================================
--  CYBRON — Cyber Fraud Defense & Coordination Platform
--  A Tech Eagles product, under Mahakumbrix Innovation
--  Target: MySQL 8.4.9  |  Engine: InnoDB  |  Charset: utf8mb4
-- ============================================================
--  Usage:  mysql -u root -p < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS cybron
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

USE cybron;

SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
--  USERS  — every stakeholder, authenticated via Google OAuth
-- ------------------------------------------------------------
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  google_id       VARCHAR(64)     NOT NULL,
  email           VARCHAR(190)    NOT NULL,
  name            VARCHAR(150)    NOT NULL,
  avatar          VARCHAR(500)    DEFAULT NULL,
  phone           VARCHAR(20)     DEFAULT NULL,
  role            ENUM(
                    'victim','advocate','forensics','police',
                    'bank','government','ngo','educator','media','admin'
                  ) DEFAULT NULL,
  verification_status ENUM('pending','active','rejected','suspended')
                  NOT NULL DEFAULT 'pending',
  organisation    VARCHAR(190)    DEFAULT NULL,   -- bank name, dept, firm, NGO
  bio             TEXT            DEFAULT NULL,
  city            VARCHAR(120)    DEFAULT NULL,
  last_login_at   TIMESTAMP       NULL DEFAULT NULL,
  created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
                                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_google_id (google_id),
  UNIQUE KEY uq_email (email),
  KEY idx_role (role),
  KEY idx_status (verification_status)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  VERIFICATION REQUESTS — KYC / dept proof for sensitive roles
-- ------------------------------------------------------------
DROP TABLE IF EXISTS verification_requests;
CREATE TABLE verification_requests (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id       BIGINT UNSIGNED NOT NULL,
  role          VARCHAR(30)     NOT NULL,
  doc_type      VARCHAR(100)    DEFAULT NULL,   -- bar council id, dept id, etc.
  doc_path      VARCHAR(500)    DEFAULT NULL,
  note          TEXT            DEFAULT NULL,
  status        ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  reviewed_by   BIGINT UNSIGNED DEFAULT NULL,
  reviewed_at   TIMESTAMP       NULL DEFAULT NULL,
  created_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id),
  KEY idx_status (status),
  CONSTRAINT fk_vr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  CASES — one fraud incident = one case = one Case Room
-- ------------------------------------------------------------
DROP TABLE IF EXISTS cases;
CREATE TABLE cases (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  case_code     VARCHAR(30)     NOT NULL,        -- CRK-2026-00001
  victim_id     BIGINT UNSIGNED NOT NULL,
  title         VARCHAR(200)    NOT NULL,
  fraud_type    ENUM('upi_banking','otp','job','investment','identity','sim_swap','other')
                NOT NULL DEFAULT 'other',
  amount_lost   DECIMAL(12,2)   DEFAULT 0.00,
  description   TEXT            DEFAULT NULL,
  status        ENUM('open','triage','in_progress','escalated','resolved','closed')
                NOT NULL DEFAULT 'open',
  priority      ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  created_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
                                ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_case_code (case_code),
  KEY idx_victim (victim_id),
  KEY idx_status (status),
  KEY idx_type (fraud_type),
  CONSTRAINT fk_case_victim FOREIGN KEY (victim_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  CASE PARTICIPANTS — who is in the Case Room (RBAC per case)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS case_participants;
CREATE TABLE case_participants (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  case_id     BIGINT UNSIGNED NOT NULL,
  user_id     BIGINT UNSIGNED NOT NULL,
  role_in_case VARCHAR(30)    NOT NULL,         -- advocate, police, bank...
  added_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_case_user (case_id, user_id),
  KEY idx_user (user_id),
  CONSTRAINT fk_cp_case FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE,
  CONSTRAINT fk_cp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  CASE TIMELINE — the shared event log everyone sees
-- ------------------------------------------------------------
DROP TABLE IF EXISTS case_events;
CREATE TABLE case_events (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  case_id     BIGINT UNSIGNED NOT NULL,
  actor_id    BIGINT UNSIGNED DEFAULT NULL,
  event_type  VARCHAR(50)     NOT NULL,         -- report_filed, freeze_requested, fir, recovered
  detail      TEXT            DEFAULT NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_case (case_id),
  CONSTRAINT fk_ce_case FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  CASE MESSAGES — Case Room chat
-- ------------------------------------------------------------
DROP TABLE IF EXISTS case_messages;
CREATE TABLE case_messages (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  case_id     BIGINT UNSIGNED NOT NULL,
  sender_id   BIGINT UNSIGNED NOT NULL,
  body        TEXT            NOT NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_case (case_id),
  CONSTRAINT fk_cm_case FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE,
  CONSTRAINT fk_cm_user FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  CASE FILES — evidence attachments
-- ------------------------------------------------------------
DROP TABLE IF EXISTS case_files;
CREATE TABLE case_files (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  case_id     BIGINT UNSIGNED NOT NULL,
  uploaded_by BIGINT UNSIGNED NOT NULL,
  file_name   VARCHAR(255)    NOT NULL,
  file_path   VARCHAR(500)    NOT NULL,
  file_type   VARCHAR(100)    DEFAULT NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_case (case_id),
  CONSTRAINT fk_cf_case FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  WAR ROOM — collective planning boards (kanban)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS warroom_boards;
CREATE TABLE warroom_boards (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title       VARCHAR(200)    NOT NULL,
  kind        ENUM('campaign','policy','threat','general') NOT NULL DEFAULT 'general',
  description TEXT            DEFAULT NULL,
  created_by  BIGINT UNSIGNED NOT NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_kind (kind),
  CONSTRAINT fk_wb_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

DROP TABLE IF EXISTS warroom_cards;
CREATE TABLE warroom_cards (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  board_id    BIGINT UNSIGNED NOT NULL,
  title       VARCHAR(255)    NOT NULL,
  body        TEXT            DEFAULT NULL,
  column_name ENUM('todo','in_progress','done') NOT NULL DEFAULT 'todo',
  assignee_id BIGINT UNSIGNED DEFAULT NULL,
  position    INT             NOT NULL DEFAULT 0,
  created_by  BIGINT UNSIGNED NOT NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_board (board_id),
  CONSTRAINT fk_wc_board FOREIGN KEY (board_id) REFERENCES warroom_boards(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  THREAT INTEL — shared scam patterns everyone feeds
-- ------------------------------------------------------------
DROP TABLE IF EXISTS threat_intel;
CREATE TABLE threat_intel (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title       VARCHAR(200)    NOT NULL,
  category    VARCHAR(80)     DEFAULT NULL,
  summary     TEXT            DEFAULT NULL,
  region      VARCHAR(120)    DEFAULT NULL,
  severity    ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  reported_by BIGINT UNSIGNED DEFAULT NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_severity (severity)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  CONSULTATIONS — free advocate/expert bookings
-- ------------------------------------------------------------
DROP TABLE IF EXISTS consultations;
CREATE TABLE consultations (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     BIGINT UNSIGNED NOT NULL,
  advocate_id BIGINT UNSIGNED DEFAULT NULL,
  case_id     BIGINT UNSIGNED DEFAULT NULL,
  contact     VARCHAR(190)    NOT NULL,
  fraud_type  VARCHAR(50)     DEFAULT NULL,
  notes       TEXT            DEFAULT NULL,
  slot_time   VARCHAR(30)     DEFAULT NULL,
  status      ENUM('requested','confirmed','done','cancelled') NOT NULL DEFAULT 'requested',
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  NOTIFICATIONS
-- ------------------------------------------------------------
DROP TABLE IF EXISTS notifications;
CREATE TABLE notifications (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     BIGINT UNSIGNED NOT NULL,
  title       VARCHAR(200)    NOT NULL,
  body        TEXT            DEFAULT NULL,
  link        VARCHAR(300)    DEFAULT NULL,
  is_read     TINYINT(1)      NOT NULL DEFAULT 0,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id),
  CONSTRAINT fk_nt_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
--  AI CHAT LOGS — CyberRakshak conversation history (optional)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS ai_chat_logs;
CREATE TABLE ai_chat_logs (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     BIGINT UNSIGNED DEFAULT NULL,
  user_msg    TEXT            NOT NULL,
  bot_msg     TEXT            DEFAULT NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------
--  SEED — make the first admin (replace email after first login)
-- ------------------------------------------------------------
-- After you log in once with Google, run:
--   UPDATE users SET role='admin', verification_status='active'
--   WHERE email='your-email@gmail.com';

-- ============================================================
--  EXPANSION — scam encyclopedia, audit log, mule reports
-- ============================================================
USE cybron;

DROP TABLE IF EXISTS scam_entries;
CREATE TABLE scam_entries (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug        VARCHAR(160)    NOT NULL,
  title       VARCHAR(200)    NOT NULL,
  category    VARCHAR(80)     DEFAULT NULL,
  how_it_works TEXT           DEFAULT NULL,
  red_flags   TEXT            DEFAULT NULL,
  what_to_do  TEXT            DEFAULT NULL,
  created_by  BIGINT UNSIGNED DEFAULT NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_slug (slug)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS audit_log;
CREATE TABLE audit_log (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     BIGINT UNSIGNED DEFAULT NULL,
  action      VARCHAR(80)     NOT NULL,
  detail      TEXT            DEFAULT NULL,
  ip          VARCHAR(45)     DEFAULT NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user (user_id),
  KEY idx_action (action)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS mule_reports;
CREATE TABLE mule_reports (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  kind        ENUM('account','upi','phone','website','other') NOT NULL DEFAULT 'other',
  value       VARCHAR(255)    NOT NULL,
  note        TEXT            DEFAULT NULL,
  reported_by BIGINT UNSIGNED DEFAULT NULL,
  reports     INT             NOT NULL DEFAULT 1,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_kind (kind),
  KEY idx_value (value)
) ENGINE=InnoDB;

-- Seed a few scam encyclopedia entries
INSERT INTO scam_entries (slug, title, category, how_it_works, red_flags, what_to_do) VALUES
('otp-fraud','OTP Fraud','OTP',
 'Scammer poses as bank/delivery/KYC agent and tricks you into sharing the OTP sent to your phone, then drains your account or authorises a payment.',
 'Anyone asking for your OTP. "Your account will be blocked." Urgency and pressure. Caller knows partial details to seem genuine.',
 'Never share OTP with anyone. Banks never ask for it. If shared, call 1930 immediately and report at cybercrime.gov.in.'),
('upi-collect-scam','UPI Collect Request Scam','UPI / Banking',
 'You get a UPI "collect" / payment request framed as "receive money". Approving it and entering your PIN actually SENDS money to the scammer.',
 '"Enter PIN to receive money" (you never need a PIN to receive). Unknown collect requests. Fake buyer on OLX/marketplace.',
 'You never enter a UPI PIN to RECEIVE money. Decline unknown requests. Report the UPI ID and call 1930.'),
('job-fraud','Fake Job / Task Scam','Job',
 'Victim is offered easy work-from-home tasks (liking videos, rating hotels). Small early payouts build trust, then larger "deposits" are demanded and never returned.',
 'Upfront deposits to "unlock" earnings. Telegram/WhatsApp-only jobs. Too-good payouts. Pressure to recruit others.',
 'Never pay to get a job. Stop, screenshot everything, report at cybercrime.gov.in and call 1930.'),
('digital-arrest','Digital Arrest Scam','Identity',
 'Fraudsters impersonate police/CBI/customs over video call, claim your ID is linked to a crime, and keep you on call under "digital arrest" until you transfer money.',
 'Video call from "police/CBI". Threats of arrest. Demand for secrecy. Asking to transfer to a "safe account".',
 'There is no such thing as digital arrest. Cut the call, talk to family, call 1930 and report immediately.');
