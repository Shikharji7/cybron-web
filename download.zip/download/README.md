# Cybron

**Cyber Fraud Defense & Coordination Platform**
A Tech Eagles product, under Mahakumbrix Innovation.

A free platform where every stakeholder in the cyber-fraud chain — victims,
advocates, police, banks, forensics, NGOs, educators, government and media —
meets in one shared **Case Room** and plans together in a **War Room**.

- Stack: HTML / CSS / JS · PHP 8.5.4 · MySQL 8.4.9
- Auth: Google OAuth
- AI: CyberRakshak (OpenRouter, multi-model fallback) behind a server-side proxy
- Languages: all major Indian languages via Google Translate + multilingual AI replies
- Mobile-first, dark "void + cyan" theme

---

## 1. Requirements
- PHP 8.5.4 with `pdo_mysql` and `curl` extensions
- MySQL 8.4.9
- A web server (Apache/Nginx) with HTTPS at your domain

## 2. Database
```bash
mysql -u root -p < sql/schema.sql
```
This creates the `cybron` database and all tables.

## 3. Secrets
Edit `config/secrets.php` and fill in:
- MySQL: `DB_USER`, `DB_PASS` (and host/name if different)
- Google OAuth: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`
- AI: `OPENROUTER_API_KEY` — from https://openrouter.ai/keys
  (the old public Groq key from the prototype must be revoked).

Keep `secrets.php` out of version control. `.htaccess` already blocks direct access.

## 4. Domain
Open `config/config.php` and confirm `BASE_URL`.
Default is `https://cybron.in`. **If your domain is actually `cyberon.in`,
change only that one line.**

## 5. Google OAuth setup
1. Go to https://console.cloud.google.com → APIs & Services → Credentials
2. Create an **OAuth client ID** (type: Web application)
3. Authorised redirect URI:
   `https://cybron.in/auth/google-callback.php`
4. Copy the client ID + secret into `config/secrets.php`

## 6. Make yourself admin
Log in once with Google, then run:
```sql
UPDATE users SET role='admin', verification_status='active'
WHERE email='your-email@gmail.com';
```

---

## Project structure
```
cybron/
├── index.php              Landing page + AI chat widget
├── dashboard.php          Role-aware dashboard
├── sql/schema.sql         Full MySQL schema
├── config/
│   ├── config.php         Branding, domain, social, roles
│   ├── secrets.php        DB + OAuth + AI keys (fill in)
│   └── db.php             PDO connection
├── includes/
│   ├── functions.php      Auth guards, CSRF, helpers
│   ├── header.php         Nav + branding
│   └── footer.php         Footer + social links
├── assets/
│   ├── css/style.css      Shared theme
│   └── js/main.js         Chat client
├── auth/
│   ├── google-login.php   OAuth redirect
│   ├── google-callback.php OAuth callback
│   ├── select-role.php    First-time role pick
│   └── logout.php
├── api/chat.php           CyberRakshak AI proxy (key stays server-side)
└── .htaccess
```

## Status — what's built (Phase 0–1)
- [x] Branding, config, social links
- [x] Full MySQL schema (users, cases, case rooms, war room, threat intel…)
- [x] Google OAuth login + role selection + verification routing
- [x] Role-aware dashboard shell
- [x] Secure AI proxy (no exposed key) — OpenRouter, model fallback chain
- [x] Mobile-first landing page
- [x] AI fraud check (triage) on landing — works in any Indian language
- [x] AI complaint-draft generator (ai-draft.php)
- [x] Site-wide Google Translate (all Indian languages)
- [x] Multilingual AI replies (CyberRakshak answers in the user's language)

## Shipped features
Auth & roles · Google OAuth · verification routing · role-aware dashboard ·
Case Room (timeline, chat, evidence upload, participants, status, Jitsi video) ·
AI fraud triage · AI complaint draft · AI case summary · AI legal-sections ·
AI scam-message checker · AI encyclopedia generator (admin) ·
War Room (kanban boards + threat-intel feed) · verified stakeholder directory ·
free advocate/expert booking · admin verification panel + audit log ·
scam encyclopedia (seeded) · safety guides · awareness quiz (XP/streak) ·
public stats (Chart.js) · fraud-alert ticker · all-Indian-language Google Translate ·
multilingual AI · installable PWA (manifest + service worker) · mobile nav.

## Page map
Public: index, encyclopedia, scam-checker, stats, guides, quiz, directory
Auth:   auth/google-login, google-callback, select-role, logout
App:    dashboard, case-new, case, warroom, board, book
Admin:  admin
APIs:   api/chat, ai-triage, ai-draft, ai-summary, ai-legal, ai-scam-check,
        ai-encyclopedia, case-action, case-upload, board-action

## Telegram bot
- @RakshakCyberBot (https://t.me/RakshakCyberBot) is linked across the site —
  hero CTA, chat widget, footer social row, and emergency links.
- The bot itself is yours; point it at the same MySQL DB + OpenRouter key to
  share cases and AI with the web app.

## Remaining polish (optional, you guide)
- [ ] Real-time chat (websockets/polling) in the Case Room
- [ ] Drag-and-drop kanban (currently arrow buttons)
- [ ] State-level scam heatmap (geo)
- [ ] WhatsApp/email send-out beyond best-effort mail()
- [ ] Chain-of-custody log for evidence

---
© 2026 Mahakumbrix Innovation · Built for Digital India · Cyber helpline 1930
