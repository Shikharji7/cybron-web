<?php
/** CYBRON — AI-generate a scam encyclopedia entry (admin) */
declare(strict_types=1);
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/ai.php';
require_admin();

$in = json_decode(file_get_contents('php://input'), true) ?: [];
if (!csrf_check($in['csrf'] ?? null)) json_out(['error' => 'Bad token'], 403);
$topic = trim((string)($in['topic'] ?? ''));
if ($topic === '') json_out(['error' => 'Topic required'], 400);

$res = ai_complete([
  ['role'=>'system','content'=>'Create a scam encyclopedia entry for an Indian cyber-safety site. Respond ONLY with JSON keys: title, category, how_it_works, red_flags, what_to_do. Keep each field concise and factual.'],
  ['role'=>'user','content'=>'Scam: ' . mb_substr($topic, 0, 200)],
], ['temperature'=>0.4,'max_tokens'=>700,'json'=>true]);

if (!$res['ok']) json_out(['error' => 'AI busy'], 502);
$d = ai_parse_json($res['reply']);
if (!$d || empty($d['title'])) json_out(['error' => 'Could not generate'], 502);

$slug = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $d['title']), '-'));
try {
    db()->prepare('INSERT INTO scam_entries (slug,title,category,how_it_works,red_flags,what_to_do,created_by) VALUES (?,?,?,?,?,?,?)')
        ->execute([$slug, $d['title'], $d['category'] ?? 'Other', $d['how_it_works'] ?? '', $d['red_flags'] ?? '', $d['what_to_do'] ?? '', $_SESSION['user_id']]);
} catch (Throwable $e) {
    json_out(['ok' => true, 'slug' => $slug]); // exists already
}
audit('encyclopedia_generate', $slug);
json_out(['ok' => true, 'slug' => $slug]);
