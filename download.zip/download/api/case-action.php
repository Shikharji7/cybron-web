<?php
/** CYBRON — Case Actions Handler (Hardened) */
declare(strict_types=1);
require_once __DIR__ . '/../includes/functions.php';
require_active();

// Get input from POST request
$in = json_decode(file_get_contents('php://input'), true) ?: [];

// CSRF Security Check
if (!csrf_check($in['csrf'] ?? null)) {
    json_out(['error' => 'Security token invalid'], 403);
}

// Case Access Validation
$caseId = (int)($in['case_id'] ?? 0);
if (!$caseId || !can_access_case($caseId)) {
    json_out(['error' => 'Access denied'], 403);
}

$me     = current_user();
$action = $in['action'] ?? '';

switch ($action) {
    case 'message':
        $body = trim((string)($in['body'] ?? ''));
        if ($body === '') json_out(['error' => 'Message is empty'], 400);
        
        // Insert message
        db()->prepare('INSERT INTO case_messages (case_id, sender_id, body) VALUES (?, ?, ?)')
            ->execute([$caseId, $me['id'], mb_substr($body, 0, 2000)]);
            
        json_out(['ok' => true]);
        break;

    case 'status':
        $status = $in['status'] ?? '';
        $valid  = ['open', 'triage', 'in_progress', 'escalated', 'resolved', 'closed'];
        
        if (!in_array($status, $valid, true)) {
            json_out(['error' => 'Invalid status provided'], 400);
        }
        
        db()->prepare('UPDATE cases SET status=? WHERE id=?')->execute([$status, $caseId]);
        
        // Log event and audit
        case_event($caseId, 'status_changed', 'Status updated to: ' . str_replace('_', ' ', $status));
        audit('case_status', "#$caseId changed to $status");
        
        json_out(['ok' => true]);
        break;

    case 'add_participant':
        // Auth check: Owner or Admin only
        $stmt = db()->prepare('SELECT victim_id FROM cases WHERE id=?');
        $stmt->execute([$caseId]);
        $case = $stmt->fetch();
        
        $owner = (int)($case['victim_id'] ?? 0);
        if ($owner !== (int)$me['id'] && !is_admin()) {
            json_out(['error' => 'Unauthorized: You are not the case owner'], 403);
        }

        $email = trim((string)($in['email'] ?? ''));
        $u = db()->prepare("SELECT * FROM users WHERE email=? AND verification_status='active' LIMIT 1");
        $u->execute([$email]);
        $user = $u->fetch();
        
        if (!$user) json_out(['error' => 'User not found or inactive'], 404);
        if (empty($user['role']) || $user['role'] === 'victim') json_out(['error' => 'Invalid user role'], 400);

        try {
            db()->prepare('INSERT INTO case_participants (case_id, user_id, role_in_case) VALUES (?, ?, ?)')
                ->execute([$caseId, $user['id'], $user['role']]);
        } catch (Throwable $e) {
            json_out(['error' => 'User is already a participant'], 409);
        }
        
        // Notify and Log
        case_event($caseId, 'participant_added', $user['name'] . ' joined as ' . role_label($user['role']));
        notify((int)$user['id'], 'Added to a case', 'You were added to a Cybron case.', '/case.php?id=' . $caseId);
        
        json_out(['ok' => true, 'name' => $user['name']]);
        break;

    default:
        json_out(['error' => 'Action not supported'], 400);
}