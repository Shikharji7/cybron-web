<?php
/** CYBRON — Case Evidence Upload Handler */
declare(strict_types=1);
require_once __DIR__ . '/../includes/functions.php';
require_active();

// Security: CSRF Check
if (!csrf_check($_POST['csrf'] ?? null)) {
    json_out(['error' => 'Security token invalid'], 403);
}

// Security: Case Access Validation
$caseId = (int)($_POST['case_id'] ?? 0);
if (!$caseId || !can_access_case($caseId)) {
    json_out(['error' => 'Unauthorized access'], 403);
}

// Validation: File exists
if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    json_out(['error' => 'Upload failed or no file provided'], 400);
}

// Validation: File Type & Size
$allowed = ['jpg','jpeg','png','gif','pdf','txt','doc','docx','mp3','wav','m4a','webp'];
$ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

if (!in_array($ext, $allowed, true)) {
    json_out(['error' => 'File type not allowed'], 400);
}

if ($_FILES['file']['size'] > 15 * 1024 * 1024) { // 15MB Limit
    json_out(['error' => 'File too large (Max 15MB)'], 400);
}

// Path Management
$dir = __DIR__ . '/../uploads/case_' . $caseId;
if (!is_dir($dir)) {
    @mkdir($dir, 0775, true);
}

// Security: Random Filename to prevent path traversal/collision
$safeName = bin2hex(random_bytes(8)) . '.' . $ext;
$relPath = 'uploads/case_' . $caseId . '/' . $safeName;
$fullPath = __DIR__ . '/../' . $relPath;

// Move File
if (!move_uploaded_file($_FILES['file']['tmp_name'], $fullPath)) {
    json_out(['error' => 'Server failed to save file'], 500);
}

// Database Record
$me = current_user();
db()->prepare('INSERT INTO case_files (case_id, uploaded_by, file_name, file_path, file_type) VALUES (?, ?, ?, ?, ?)')
    ->execute([$caseId, $me['id'], $_FILES['file']['name'], $relPath, $ext]);

// Log Event
case_event($caseId, 'evidence_uploaded', 'File: ' . $_FILES['file']['name']);

json_out(['ok' => true]);