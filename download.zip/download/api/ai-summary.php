<?php
/** CYBRON — AI case summary */
declare(strict_types=1);
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/ai.php';
require_active();

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$caseId = (int)($in['case_id'] ?? 0);
if (!$caseId || !can_access_case($caseId)) json_out(['error' => 'No access'], 403);

$c = db()->prepare('SELECT * FROM cases WHERE id=?'); $c->execute([$caseId]); $case = $c->fetch();
$ev = db()->prepare('SELECT event_type, detail, created_at FROM case_events WHERE case_id=? ORDER BY created_at ASC');
$ev->execute([$caseId]); $events = $ev->fetchAll();

$log = "Case {$case['case_code']} — {$case['title']} ({$case['fraud_type']}, Rs {$case['amount_lost']}).\n"
     . "Description: {$case['description']}\nTimeline:\n";
foreach ($events as $e) { $log .= "- {$e['created_at']} {$e['event_type']} {$e['detail']}\n"; }

$res = ai_complete([
  ['role'=>'system','content'=>'Summarise this Indian cyber-fraud case in 3-4 sentences for the responders: what happened, current status, and the single most important next action. Be factual and concise.'],
  ['role'=>'user','content'=>$log],
], ['temperature'=>0.3,'max_tokens'=>400]);

json_out($res['ok'] ? ['summary'=>$res['reply']] : ['error'=>'AI busy'], $res['ok']?200:502);
