<?php
/** CYBRON — AI scam-message checker (Protected) */
declare(strict_types=1);
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/ai.php';

// 1. SECURITY: CSRF Protection
// Frontend se jo 'X-CSRF-TOKEN' header aa raha hai, use check karte hain
$headers = getallheaders();
$token = $headers['X-CSRF-TOKEN'] ?? '';

if (!csrf_check($token)) {
    json_out(['error' => 'Invalid security token. Please refresh the page.'], 403);
}

// 2. RATE LIMITING: Prevent AI API Spamming
// Ek user 5 second me sirf ek request bhej sakta hai
session_start();
$last_check = $_SESSION['last_ai_check'] ?? 0;
if ((time() - $last_check) < 5) {
    json_out(['error' => 'Please wait a few seconds before checking again.'], 429);
}
$_SESSION['last_ai_check'] = time();

// 3. INPUT HANDLING
$raw_input = file_get_contents('php://input');
$in = json_decode($raw_input, true) ?: [];
$text = trim((string)($in['text'] ?? ''));

if ($text === '') {
    json_out(['error' => 'Paste a message or link to analyze.'], 400);
}

// 4. AI PROCESSING
// Input length limit 1500 chars (Safety + Cost control)
$sanitized_text = mb_substr($text, 0, 1500);

$res = ai_complete([
  ['role' => 'system', 'content' => 'You are an expert Cyber Security analyst for India. Analyze SMS/WhatsApp/Email for scams. Respond ONLY with raw JSON: {"verdict": "safe"|"suspicious"|"scam", "confidence": int(0-100), "reasons": ["short string 1", "short string 2"], "advice": "short string"}. Keep language identical to input.'],
  ['role' => 'user', 'content' => $sanitized_text],
], ['temperature' => 0.2, 'max_tokens' => 500, 'json' => true]);

if (!$res['ok']) {
    // Log the error internally for debugging
    error_log("AI API Error: " . ($res['reply'] ?? 'Unknown error'));
    json_out(['error' => 'AI engine currently unavailable. Please try again or call ' . CYBER_HELPLINE], 502);
}

$p = ai_parse_json($res['reply']);

if (!$p) {
    json_out(['error' => 'Could not parse analysis.'], 502);
}

// Success
json_out($p, 200);