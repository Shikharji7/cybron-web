<?php
/** CYBRON — AI legal sections suggester */
declare(strict_types=1);
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/ai.php';

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$desc = trim((string)($in['description'] ?? ''));
if ($desc === '') json_out(['error'=>'Describe the fraud'], 400);

$res = ai_complete([
  ['role'=>'system','content'=>'You are an Indian cyber-law expert. Given a fraud description, list the likely applicable legal provisions (IT Act 2000 sections and Bharatiya Nyaya Sanhita / IPC sections) with a one-line reason each. Add a short disclaimer that final sections are decided by police/court. Keep it under 200 words.'],
  ['role'=>'user','content'=>mb_substr($desc,0,1500)],
], ['temperature'=>0.3,'max_tokens'=>500]);

json_out($res['ok'] ? ['reply'=>$res['reply']] : ['error'=>'AI busy'], $res['ok']?200:502);
