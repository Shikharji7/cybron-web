<?php
/**
 * CYBRON — AI complaint draft
 * POST { name, description, amount?, fraud_type?, lang? }
 * Returns a ready-to-paste complaint draft for cybercrime.gov.in.
 */
declare(strict_types=1);
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/ai.php';

header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['error' => 'POST only'], 405);
}

$in    = json_decode(file_get_contents('php://input'), true) ?: [];
$name  = trim((string)($in['name'] ?? 'Complainant'));
$desc  = trim((string)($in['description'] ?? ''));
$amt   = (float)($in['amount'] ?? 0);
$type  = trim((string)($in['fraud_type'] ?? ''));
$lang  = trim((string)($in['lang'] ?? 'English'));
if ($desc === '') {
    json_out(['error' => 'Describe what happened'], 400);
}
$desc = mb_substr($desc, 0, 2000);

$system = "You are CyberRakshak AI. Draft a clear, factual cyber-fraud complaint that the "
        . "victim can submit on the National Cyber Crime Reporting Portal (cybercrime.gov.in) "
        . "or to a police cyber cell in India. Use a formal complaint structure: a 'To' line "
        . "(Cyber Crime Cell), subject, a chronological factual account in first person, the "
        . "amount involved, and a request for action (freeze, trace, recover, register FIR). "
        . "Do NOT invent facts not given. Write the entire draft in {$lang}. Return plain text only.";

$user = "Complainant name: {$name}\nFraud type: {$type}\nAmount (INR): {$amt}\nWhat happened: {$desc}";

$res = ai_complete([
    ['role' => 'system', 'content' => $system],
    ['role' => 'user',   'content' => $user],
], ['temperature' => 0.4, 'max_tokens' => 900]);

if (!$res['ok']) {
    json_out(['error' => 'AI busy. Call ' . CYBER_HELPLINE], 502);
}

json_out(['draft' => $res['reply'], 'model' => $res['model']]);
