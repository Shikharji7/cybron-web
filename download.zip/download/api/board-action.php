<?php
/** CYBRON — Board Actions (Hardened) */
declare(strict_types=1);
require_once __DIR__ . '/../includes/functions.php';
require_active();

$in = json_decode(file_get_contents('php://input'), true) ?: [];
if (!csrf_check($in['csrf'] ?? null)) json_out(['error' => 'Bad token'], 403);
$me = current_user();

// Database connection
$pdo = db();

switch ($in['action'] ?? '') {
    case 'add_card':
        $boardId = (int)($in['board_id'] ?? 0);
        $title   = trim((string)($in['title'] ?? ''));

        // 1. Authorization: Check if user is member of this board
        $stmt = $pdo->prepare('SELECT 1 FROM warroom_board_members WHERE board_id=? AND user_id=?');
        $stmt->execute([$boardId, $me['id']]);
        if (!$stmt->fetch() && !is_admin()) {
            json_out(['error' => 'Unauthorized'], 403);
        }

        if (!$boardId || $title === '') json_out(['error' => 'Missing data'], 400);
        
        $pdo->prepare('INSERT INTO warroom_cards (board_id, title, column_name, created_by) VALUES (?,?,?,?)')
            ->execute([$boardId, mb_substr($title, 0, 255), 'todo', $me['id']]);
        
        json_out(['ok' => true]);
        break;

    case 'move_card':
        $cardId = (int)($in['card_id'] ?? 0);
        $col    = $in['column'] ?? '';
        
        if (!in_array($col, ['todo','in_progress','done'], true)) {
            json_out(['error' => 'Bad column'], 400);
        }

        /**
         * 2. Security: Ensure user can only move cards of boards they belong to.
         * We join with warroom_board_members to enforce authorization at the DB level.
         */
        $stmt = $pdo->prepare('
            UPDATE warroom_cards c
            JOIN warroom_board_members bm ON c.board_id = bm.board_id
            SET c.column_name = ?
            WHERE c.id = ? AND bm.user_id = ?
        ');
        $stmt->execute([$col, $cardId, $me['id']]);
        
        // Check if rows were actually affected
        if ($stmt->rowCount() === 0) {
            json_out(['error' => 'Unauthorized or Card not found'], 403);
        }
        
        json_out(['ok' => true]);
        break;

    default:
        json_out(['error' => 'Unknown action'], 400);
}