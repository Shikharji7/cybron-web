<?php
/** CYBRON — Centralized API Handler */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_active(); // Sirf log-in user access kar sakta hai

header('Content-Type: application/json');

// JSON input read karo
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

// Security: CSRF Check
if (!csrf_check($input['csrf'] ?? null)) {
    echo json_encode(['error' => 'CSRF verification failed']);
    exit;
}

$action = $input['action'] ?? '';
$caseId = (int)($input['case_id'] ?? 0);

// Access check: Kya user is case ko access kar sakta hai?
if ($caseId > 0 && !can_access_case($caseId)) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$me = current_user();

switch ($action) {
    case 'message':
        $body = trim($input['body'] ?? '');
        if ($body === '') { echo json_encode(['error' => 'Message khali hai']); exit; }
        
        $stmt = db()->prepare('INSERT INTO case_messages (case_id, sender_id, body) VALUES (?,?,?)');
        $stmt->execute([$caseId, $me['id'], $body]);
        echo json_encode(['ok' => true]);
        break;

    case 'status':
        $status = $input['status'] ?? 'open';
        $valid = ['open','triage','in_progress','escalated','resolved','closed'];
        if (!in_array($status, $valid, true)) { echo json_encode(['error' => 'Invalid status']); exit; }
        
        db()->prepare('UPDATE cases SET status=? WHERE id=?')->execute([$status, $caseId]);
        case_event($caseId, 'status_changed', "Status set to $status");
        echo json_encode(['ok' => true]);
        break;

    default:
        echo json_encode(['error' => 'Invalid action']);
}
?>