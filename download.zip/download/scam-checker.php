<?php
/** CYBRON — scam message / link checker (Optimized) */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Scam checker';
require __DIR__ . '/includes/header.php';
?>
<section class="page">
  <div class="wrap" style="max-width:640px">
    <div class="section-head">
      <span class="section-tag">[ AI · SECURE ]</span>
      <h2 style="font-size:28px">Is this a scam?</h2>
      <p>Paste a suspicious SMS, WhatsApp message, email or link. AI checks it in seconds — in any Indian language.</p>
    </div>
    
    <input type="hidden" id="csrf_token" value="<?= e(csrf_token()) ?>">

    <div class="ai-check">
      <textarea id="scamText" rows="5" placeholder="Paste the message or link here…" style="width:100%;"></textarea>
      <button id="scamBtn" class="btn btn-primary btn-lg btn-block" style="margin-top:14px">
        <span class="btn-text">Check now →</span>
      </button>
      <p style="font-size:11px; color:var(--text-muted, #8b9ab0); margin-top:8px; text-align:center;">
        <i class="fa-solid fa-shield-halved"></i> AI analysis is for advisory purposes only.
      </p>

      <div class="ai-result" id="scamResult" style="opacity:0; transition:opacity 0.4s ease;">
        <div class="ai-badges" id="scamBadges" style="margin-top:20px;"></div>
        <ul class="ai-steps" id="scamReasons"></ul>
        <p id="scamAdvice" style="margin-top:10px;font-size:15px; color:#fff;"></p>
      </div>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>

<script>
(function(){
  var btn = document.getElementById('scamBtn');
  var API = "<?= e(BASE_URL) ?>/api/ai-scam-check.php";
  
  btn.addEventListener('click', async function(){
    var t = document.getElementById('scamText').value.trim();
    var token = document.getElementById('csrf_token').value;
    
    if(!t) {
        showCybronToast("Please paste a message first!", "warning");
        return;
    }

    var res = document.getElementById('scamResult'),
        badges = document.getElementById('scamBadges'),
        reasons = document.getElementById('scamReasons'),
        advice = document.getElementById('scamAdvice'),
        btnText = btn.querySelector('.btn-text');

    // UI Loading State
    btn.disabled = true;
    btnText.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Analyzing threat signatures...';
    res.style.opacity = '0';
    badges.innerHTML = ''; 
    reasons.innerHTML = ''; 
    advice.textContent = '';

    try{
      var r = await (await fetch(API, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token // Sending token for backend validation
        },
        body: JSON.stringify({text: t})
      })).json();

      if(r.error) {
        showCybronToast(r.error, "error");
        return;
      }

      var v = r.verdict || '?';
      var cls = v === 'scam' ? 'pill-red' : (v === 'suspicious' ? 'pill-amber' : 'pill-cyan');
      
      // Update UI
      var p = document.createElement('span');
      p.className = 'pill ' + cls;
      p.textContent = v.toUpperCase() + ' · ' + (r.confidence || 0) + '%';
      badges.appendChild(p);

      (r.reasons || []).forEach(function(x){
        var li = document.createElement('li');
        li.textContent = x;
        reasons.appendChild(li);
      });
      
      advice.textContent = r.advice || '';
      res.style.opacity = '1';

    } catch(e) {
      showCybronToast("AI Engine is busy. Call 1930 for urgent help.", "error");
    } finally {
      btn.disabled = false;
      btnText.textContent = 'Check now →';
    }
  });
})();
</script>