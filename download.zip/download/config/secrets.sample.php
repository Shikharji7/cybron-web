<?php
/**
 * CYBRON — SECRETS  (do NOT commit / keep outside web root if possible)
 * Fill these in on your server.
 */
declare(strict_types=1);

// ---- MySQL ----
const DB_HOST = '127.0.0.1';
const DB_PORT = '3306';
const DB_NAME = 'cybron';
const DB_USER = 'root';
const DB_PASS = 'CHANGE_ME';

// ---- Google OAuth (https://console.cloud.google.com) ----
// Authorised redirect URI must be: https://cybron.in/auth/google-callback.php
const GOOGLE_CLIENT_ID     = 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = 'YOUR_GOOGLE_CLIENT_SECRET';

// ---- OpenRouter AI key (https://openrouter.ai/keys) ----
const OPENROUTER_API_KEY = 'sk-or-v1-YOUR_OPENROUTER_KEY';
