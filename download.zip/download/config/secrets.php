<?php
/**
 * CYBRON — SECRETS  (do NOT commit / keep outside web root if possible)
 * Fill these in on your server.
 */
declare(strict_types=1);

// ---- MySQL ----
const DB_HOST = 'sql206.infinityfree.com';
const DB_PORT = '3306';
const DB_NAME = 'if0_42220361_cybron';
const DB_USER = 'if0_42220361';
const DB_PASS = 'kXsfjAF7Jm00';

// ---- Google OAuth (https://console.cloud.google.com) ----
// Authorised redirect URI must be: https://cybron.in/auth/google-callback.php
const GOOGLE_CLIENT_ID     = '865726319784-98273e2q7sgubl46jcacq00grfs42ha5.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = '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';

// ---- OpenRouter AI key (https://openrouter.ai/keys) ----
const OPENROUTER_API_KEY = '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';
