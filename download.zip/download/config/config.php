<?php
/**
 * CYBRON — central configuration
 * A Tech Eagles product, under Mahakumbrix Innovation
 * PHP 8.5.4 / MySQL 8.4.9
 */
declare(strict_types=1);

// ---- Secrets (Google OAuth + AI key) live in a separate, non-public file ----
require_once __DIR__ . '/secrets.php';

// ---- Site / domain --------------------------------------------------------
// NOTE: confirm spelling — your handle is "cybron1930", so we use cybron.in.
// If your domain is actually cyberon.in, change ONLY this line.
const BASE_URL = 'https://cybron.in';

// ---- Branding -------------------------------------------------------------
const BRAND_NAME    = 'Cybron';
const BRAND_TAGLINE = 'Cyber Fraud Defense & Coordination';
const BRAND_PARENT  = 'Mahakumbrix Innovation';
const BRAND_DEV     = 'Tech Eagles';
const BRAND_CREDIT  = 'Cybron — a Tech Eagles product · © 2026 Mahakumbrix Innovation';
const CYBER_HELPLINE = '1930';
const TELEGRAM_BOT   = 'https://t.me/RakshakCyberBot';

// ---- Social links ---------------------------------------------------------
const SOCIAL = [
    'telegram' => 'https://t.me/RakshakCyberBot',
    'x'        => 'https://x.com/cybron1930',
    'instagram'=> 'https://www.instagram.com/cybron1930',
    'youtube'  => 'https://www.youtube.com/@cybron1930',
    'whatsapp' => 'https://whatsapp.com/channel/0029VbDQlaqEquiJsM2OX93i',
];

// ---- Google OAuth endpoints ----------------------------------------------
const GOOGLE_AUTH_URL     = 'https://accounts.google.com/o/oauth2/v2/auth';
const GOOGLE_TOKEN_URL    = 'https://oauth2.googleapis.com/token';
const GOOGLE_USERINFO_URL = 'https://www.googleapis.com/oauth2/v3/userinfo';
const GOOGLE_REDIRECT_URI = BASE_URL . '/auth/google-callback.php';

// ---- AI (CyberRakshak via OpenRouter) ------------------------------------
const AI_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
// Fallback chain: tried top to bottom until one responds.
const AI_MODELS  = [
    'meta-llama/llama-3.3-70b-instruct:free',
    'google/gemini-2.0-flash-exp:free',
    'meta-llama/llama-3.1-8b-instruct',
    'mistralai/mistral-7b-instruct',
];
const AI_REFERER = BASE_URL;          // OpenRouter HTTP-Referer
const AI_TITLE   = 'Cybron';          // OpenRouter X-Title

// InfinityFree blocks direct outbound calls to AI APIs from PHP curl.
// chat.php instead calls this small Cloudflare Worker (free, runs outside
// InfinityFree) which holds the real OpenRouter key and does the AI call.
const CYBRON_AI_WORKER_URL    = 'https://cybron-ai.mehrotrashikhar99.workers.dev';
const CYBRON_AI_WORKER_SECRET = 'cybron-x9k2-secure-2026';

// ---- Indian languages (Google Translate widget) --------------------------
// Codes Google Translate supports. Unsupported ones are simply skipped.
const INDIAN_LANGUAGES =
    'en,hi,bn,as,gu,kn,ml,mr,ne,or,pa,sa,sd,ta,te,ur,bho,gom,mai,mni-Mtei,doi';

// ---- Roles ----------------------------------------------------------------
const ROLES = [
    'victim'     => 'Victim / Citizen',
    'advocate'   => 'Advocate (Cyber Lawyer)',
    'forensics'  => 'Cyber Forensics Expert',
    'police'     => 'Police / Cyber Cell',
    'bank'       => 'Bank / Financial Institution',
    'government' => 'Government / Regulator',
    'ngo'        => 'NGO / Support Org',
    'educator'   => 'Educator / Institution',
    'media'      => 'Media / Researcher',
];
// Roles that get instant access vs. roles needing verification
const INSTANT_ROLES  = ['victim'];
const VERIFY_ROLES   = ['advocate','forensics','police','bank','government','ngo','educator','media'];

// ---- Session --------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax',
        'cookie_secure'   => true,
    ]);
}