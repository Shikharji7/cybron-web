<?php
/** CYBRON — scam encyclopedia */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';

$slug = $_GET['slug'] ?? '';
$page_title = 'Scam wiki';
require __DIR__ . '/includes/header.php';

if ($slug !== '') {
    $s = db()->prepare('SELECT * FROM scam_entries WHERE slug=?'); $s->execute([$slug]); $entry = $s->fetch();
    if ($entry):
?>
<section class="page"><div class="wrap" style="max-width:760px">
  <a href="<?= e(BASE_URL) ?>/encyclopedia.php" class="muted">← All scams</a>
  <span class="pill pill-cyan" style="margin-top:10px;display:inline-block"><?= e($entry['category']) ?></span>
  <h2 style="font-family:'Sora';font-size:30px;margin:10px 0 20px"><?= e($entry['title']) ?></h2>
  <div class="card"><h3>How it works</h3><p class="muted" style="margin-top:8px"><?= nl2br(e($entry['how_it_works'])) ?></p></div>
  <div class="card" style="margin-top:14px"><h3>🚩 Red flags</h3><p class="muted" style="margin-top:8px"><?= nl2br(e($entry['red_flags'])) ?></p></div>
  <div class="card" style="margin-top:14px"><h3>✅ What to do</h3><p class="muted" style="margin-top:8px"><?= nl2br(e($entry['what_to_do'])) ?></p></div>
</div></section>
<?php
    else:
        echo '<section class="page"><div class="wrap"><p class="muted">Entry not found.</p></div></section>';
    endif;
    require __DIR__ . '/includes/footer.php';
    return;
}

$entries = db()->query('SELECT * FROM scam_entries ORDER BY title')->fetchAll();
?>
<section class="page"><div class="wrap">
  <div class="section-head" style="text-align:left">
    <span class="section-tag">[ SCAM WIKI ]</span>
    <h2 style="font-size:28px">Know the scams</h2>
    <p>How each fraud works, the red flags, and exactly what to do. Use the language switcher for your language.</p>
  </div>
  <div class="grid grid-3">
    <?php foreach ($entries as $en): ?>
      <a class="card" href="?slug=<?= e($en['slug']) ?>" style="text-decoration:none">
        <span class="pill pill-amber"><?= e($en['category']) ?></span>
        <h3 style="margin-top:10px"><?= e($en['title']) ?></h3>
        <p class="muted"><?= e(mb_substr($en['how_it_works'],0,90)) ?>…</p>
      </a>
    <?php endforeach; ?>
  </div>
  <?php if (is_admin()): ?>
    <div class="form-card" style="max-width:none;margin-top:24px">
      <h3 style="font-family:'Sora'">🤖 Generate a new entry (admin)</h3>
      <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
        <input id="genTopic" placeholder="Scam name, e.g. Electricity bill scam" style="flex:1;min-width:200px">
        <button id="genBtn" class="btn btn-primary">Generate</button>
      </div>
      <p id="genMsg" class="muted" style="margin-top:10px"></p>
    </div>
    <script>
    document.getElementById('genBtn').addEventListener('click', async function(){
      var t=(document.getElementById('genTopic').value||'').trim(); if(!t) return;
      var m=document.getElementById('genMsg'); m.textContent='Generating…';
      var r=await (await fetch("<?= e(BASE_URL) ?>/api/ai-encyclopedia.php",{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({topic:t,csrf:"<?= e(csrf_token()) ?>"})})).json();
      if(r.ok){location.href="?slug="+r.slug;}else{m.textContent=r.error||'Failed';}
    });
    </script>
  <?php endif; ?>
</div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
