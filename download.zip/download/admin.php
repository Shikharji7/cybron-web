<?php
/** * CYBRON — Admin Panel 
 * Full Debug Mode Enabled
 */

// 1. Force Error Reporting - Ye screen par error dikhayega agar kuch kharab hua
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2. Include functions.php - Path yahan check kar lena
// Agar file 'includes' folder mein hai, toh ye sahi hai
require_once __DIR__ . '/includes/functions.php';

// 3. Security Check
if (function_exists('require_admin')) {
    require_admin();
} else {
    // Agar functions.php load nahi ho raha, toh ye yahan error de dega
    die("Error: require_admin function not found in functions.php");
}

// Handle Flash Messages
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// --- POST HANDLING ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        die('Security violation.');
    }

    $rid = (int)($_POST['req_id'] ?? 0);
    $decision = $_POST['decision'] ?? '';

    if ($rid > 0 && in_array($decision, ['approved', 'rejected'], true)) {
        try {
            db()->beginTransaction();
            $stmt = db()->prepare('SELECT * FROM verification_requests WHERE id=? AND status="pending" FOR UPDATE');
            $stmt->execute([$rid]);
            $req = $stmt->fetch();

            if ($req) {
                $updateReq = db()->prepare('UPDATE verification_requests SET status=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?');
                $updateReq->execute([$decision, $_SESSION['user_id'], $rid]);

                $userStatus = ($decision === 'approved') ? 'active' : 'rejected';
                $updateUser = db()->prepare('UPDATE users SET verification_status=? WHERE id=?');
                $updateUser->execute([$userStatus, (int)$req['user_id']]);

                notify((int)$req['user_id'], 'Verification ' . ucfirst($decision),
                       'Your ' . role_label($req['role']) . ' role was ' . $decision . '.', '/dashboard.php');

                audit('verify_' . $decision, 'Request ID: ' . $rid . ' | Target User: ' . $req['user_id']);

                db()->commit();
                $_SESSION['flash'] = "Success: Request #{$rid} {$decision}.";
            } else {
                db()->rollBack();
                $_SESSION['flash'] = "Error: Request already processed or not found.";
            }
        } catch (Exception $e) {
            db()->rollBack();
            echo "Database Error: " . $e->getMessage(); // Ye error screen par dikhega
            exit;
        }
    }
    header('Location: admin.php');
    exit;
}

// --- DATA FETCHING ---
$pending = [];
$audit = [];
$stats = ['users' => 0, 'cases' => 0, 'pending' => 0, 'active_responders' => 0];

try {
    $pending = db()->query(
      "SELECT vr.*, u.name, u.email, u.organisation FROM verification_requests vr
       JOIN users u ON u.id=vr.user_id WHERE vr.status='pending' ORDER BY vr.created_at ASC"
    )->fetchAll();

    $stats = [
      'users' => (int)db()->query('SELECT COUNT(*) c FROM users')->fetch()['c'],
      'cases' => (int)db()->query('SELECT COUNT(*) c FROM cases')->fetch()['c'],
      'pending' => count($pending),
      'active_responders' => (int)db()->query("SELECT COUNT(*) c FROM users WHERE verification_status='active' AND role!='victim' AND role IS NOT NULL")->fetch()['c'],
    ];

    $audit = db()->query('SELECT a.*, u.name FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 20')->fetchAll();
} catch (Exception $e) {
    echo "Data Fetch Error: " . $e->getMessage();
    exit;
}

$page_title = 'Admin Control';
require __DIR__ . '/includes/header.php';
?>

<section class="page">
  <div class="wrap">
    <div class="section-head" style="text-align:left">
      <span class="section-tag">[ ADMIN ]</span>
      <h2 style="font-size:28px">Control room</h2>
    </div>

    <?php if ($flash): ?>
        <div class="card" style="border:1px solid var(--cyan); margin-bottom:20px; padding:15px; color:var(--cyan)">
            <?= e($flash) ?>
        </div>
    <?php endif; ?>

    <div class="stat-row">
      <div class="stat"><div class="num"><?= $stats['users'] ?></div><div class="lbl">Users</div></div>
      <div class="stat"><div class="num"><?= $stats['cases'] ?></div><div class="lbl">Cases</div></div>
      <div class="stat"><div class="num"><?= $stats['pending'] ?></div><div class="lbl">Pending</div></div>
      <div class="stat"><div class="num"><?= $stats['active_responders'] ?></div><div class="lbl">Responders</div></div>
    </div>

    <h3 style="font-family:'Sora';margin:28px 0 14px">Verification queue</h3>
    <?php if (empty($pending)): ?>
        <div class="card"><p class="muted">Nothing pending. 🎉</p></div>
    <?php else: ?>
      <div class="grid grid-2">
        <?php foreach ($pending as $p): ?>
          <div class="card">
            <span class="pill pill-amber"><?= e(role_label($p['role'])) ?></span>
            <h3 style="margin-top:8px"><?= e($p['name']) ?></h3>
            <p class="muted"><?= e($p['email']) ?><?= $p['organisation'] ? ' · ' . e($p['organisation']) : '' ?></p>
            <form method="post" style="display:flex;gap:8px;margin-top:12px">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="req_id" value="<?= (int)$p['id'] ?>">
              <button name="decision" value="approved" class="btn btn-primary">Approve</button>
              <button name="decision" value="rejected" class="btn btn-ghost">Reject</button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <h3 style="font-family:'Sora';margin:28px 0 14px">Recent activity</h3>
    <div class="card">
      <div class="timeline">
        <?php foreach ($audit as $a): ?>
          <div class="tl-item">
            <div class="when"><?= e($a['created_at']) ?> · <?= e($a['name'] ?? 'system') ?></div>
            <div class="what"><?= e($a['action']) ?></div>
            <?php if (!empty($a['detail'])): ?><div class="muted" style="font-size:13px"><?= e($a['detail']) ?></div><?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>