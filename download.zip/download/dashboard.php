<?php
/** CYBRON — User Dashboard */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_active(); // Ensures only logged-in users can access

$u = current_user();
$page_title = 'Dashboard';

// Fetch quick stats from database (Wrapped in try-catch)
$active_cases = 0;
$resolved_cases = 0;
$recent_cases = [];

try {
    $stmt1 = db()->prepare("SELECT COUNT(*) FROM cases WHERE victim_id = ? AND status NOT IN ('resolved', 'closed')");
    $stmt1->execute([$u['id']]);
    $active_cases = (int)$stmt1->fetchColumn();

    $stmt2 = db()->prepare("SELECT COUNT(*) FROM cases WHERE victim_id = ? AND status IN ('resolved', 'closed')");
    $stmt2->execute([$u['id']]);
    $resolved_cases = (int)$stmt2->fetchColumn();

    $stmt3 = db()->prepare("SELECT id, status, created_at FROM cases WHERE victim_id = ? ORDER BY created_at DESC LIMIT 3");
    $stmt3->execute([$u['id']]);
    $recent_cases = $stmt3->fetchAll();
} catch (Throwable $e) {
    // Fallback to 0 if tables don't exist yet
}

require __DIR__ . '/includes/header.php';
?>

<section class="page" style="position: relative; z-index: 10;">
  <div class="wrap">
    <div class="section-head" style="text-align:left; margin-bottom: 30px;">
      <span class="section-tag">[ OVERVIEW ]</span>
      <h2 style="font-size:32px">Welcome, <?= e($u['name']) ?> 👋</h2>
      <p class="muted">Here is a summary of your cyber defense operations and recent activities.</p>
    </div>

    <div class="grid grid-3" style="margin-bottom: 40px; position: relative; z-index: 10;">
      <div class="card" style="border-top: 3px solid var(--cyan, #00c8ff);">
        <h3 style="font-size: 2.5rem; margin: 0; color: var(--cyan, #00c8ff);"><?= $active_cases ?></h3>
        <p class="muted" style="margin-top: 5px; font-weight: 600;">Active Cases</p>
      </div>
      <div class="card" style="border-top: 3px solid #ffaa00;">
        <h3 style="font-size: 2.5rem; margin: 0; color: #ffaa00;">0</h3>
        <p class="muted" style="margin-top: 5px; font-weight: 600;">Pending Actions</p>
      </div>
      <div class="card" style="border-top: 3px solid #00ff88;">
        <h3 style="font-size: 2.5rem; margin: 0; color: #00ff88;"><?= $resolved_cases ?></h3>
        <p class="muted" style="margin-top: 5px; font-weight: 600;">Resolved Issues</p>
      </div>
    </div>

    <div class="grid grid-2" style="gap: 30px; position: relative; z-index: 10;">
      
      <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid var(--border, #2a3448); padding-bottom: 15px;">
            <h3 style="margin: 0; font-size: 18px;">Recent Cases</h3>
            <a href="warroom.php" style="color: var(--cyan, #00c8ff); font-size: 14px; text-decoration: none; cursor: pointer; position: relative; z-index: 20;">View All</a>
        </div>
        
        <?php if (!empty($recent_cases)): ?>
            <ul style="list-style: none; padding: 0; margin: 0;">
                <?php foreach ($recent_cases as $c): ?>
                    <li style="padding: 10px 0; border-bottom: 1px dashed rgba(255,255,255,0.1); display: flex; justify-content: space-between;">
                        <span>Case #<?= e((string)$c['id']) ?></span>
                        <span class="pill pill-cyan" style="font-size: 12px;"><?= e(ucfirst($c['status'])) ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <div style="text-align: center; padding: 30px 10px;">
                <p class="muted" style="margin-bottom: 15px;">No active cases or recent activity found.</p>
                <a href="warroom.php" class="btn" style="background: rgba(255,255,255,0.05); border: 1px solid var(--border); color: #fff; padding: 8px 16px; border-radius: 4px; text-decoration: none; font-size: 14px; cursor: pointer; display: inline-block; position: relative; z-index: 20;">Open War Room</a>
            </div>
        <?php endif; ?>
      </div>

      <div class="card">
        <h3 style="margin: 0 0 20px 0; font-size: 18px; border-bottom: 1px solid var(--border, #2a3448); padding-bottom: 15px;">Quick Actions</h3>
        <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 12px;">
            <li>
                <a href="scam-checker.php" style="display: block; padding: 12px; background: rgba(0,200,255,0.05); border: 1px solid rgba(0,200,255,0.2); border-radius: 6px; text-decoration: none; color: #e8edf5; transition: all 0.2s ease; cursor: pointer; position: relative; z-index: 20;">
                    <strong style="color: var(--cyan, #00c8ff);">🔍 Scam Check</strong>
                    <p style="margin: 4px 0 0 0; font-size: 12px; color: #8b9ab0;">Verify suspicious URLs, UPI IDs, or phone numbers.</p>
                </a>
            </li>
            <li>
                <a href="directory.php" style="display: block; padding: 12px; background: rgba(255,255,255,0.03); border: 1px solid var(--border, #2a3448); border-radius: 6px; text-decoration: none; color: #e8edf5; transition: all 0.2s ease; cursor: pointer; position: relative; z-index: 20;">
                    <strong style="color: #e8edf5;">📞 Stakeholder Directory</strong>
                    <p style="margin: 4px 0 0 0; font-size: 12px; color: #8b9ab0;">Find verified advocates, cyber cells, and forensics experts.</p>
                </a>
            </li>
            <li>
                <a href="encyclopedia.php" style="display: block; padding: 12px; background: rgba(255,255,255,0.03); border: 1px solid var(--border, #2a3448); border-radius: 6px; text-decoration: none; color: #e8edf5; transition: all 0.2s ease; cursor: pointer; position: relative; z-index: 20;">
                    <strong style="color: #e8edf5;">📚 Scam Wiki</strong>
                    <p style="margin: 4px 0 0 0; font-size: 12px; color: #8b9ab0;">Read about the latest cyber threats and defense tactics.</p>
                </a>
            </li>
        </ul>
      </div>

    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>