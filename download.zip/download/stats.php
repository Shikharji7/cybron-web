<?php
/** CYBRON — public stats */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';

try {
    $byType = db()->query("SELECT fraud_type, COUNT(*) c FROM cases GROUP BY fraud_type")->fetchAll();
    $byStatus = db()->query("SELECT status, COUNT(*) c FROM cases GROUP BY status")->fetchAll();
    $totals = [
        'users' => (int)db()->query('SELECT COUNT(*) c FROM users')->fetch()['c'],
        'cases' => (int)db()->query('SELECT COUNT(*) c FROM cases')->fetch()['c'],
        'resolved' => (int)db()->query("SELECT COUNT(*) c FROM cases WHERE status='resolved'")->fetch()['c'],
        'recovered' => (float)db()->query("SELECT COALESCE(SUM(amount_lost),0) s FROM cases WHERE status='resolved'")->fetch()['s'],
    ];
} catch (Throwable $e) { $byType=$byStatus=[]; $totals=['users'=>0,'cases'=>0,'resolved'=>0,'recovered'=>0]; }

$page_title = 'Stats';
require __DIR__ . '/includes/header.php';
?>
<section class="page"><div class="wrap">
  <div class="section-head" style="text-align:left">
    <span class="section-tag">[ TRANSPARENCY ]</span>
    <h2 style="font-size:28px">Cybron in numbers</h2>
  </div>
  <div class="stat-row">
    <div class="stat"><div class="num"><?= $totals['users'] ?></div><div class="lbl">Members</div></div>
    <div class="stat"><div class="num"><?= $totals['cases'] ?></div><div class="lbl">Cases</div></div>
    <div class="stat"><div class="num"><?= $totals['resolved'] ?></div><div class="lbl">Resolved</div></div>
    <div class="stat"><div class="num">₹<?= number_format($totals['recovered']) ?></div><div class="lbl">Value in resolved cases</div></div>
  </div>
  <div class="grid grid-2" style="margin-top:24px">
    <div class="card"><h3>By fraud type</h3><canvas id="typeChart" style="margin-top:14px"></canvas></div>
    <div class="card"><h3>By status</h3><canvas id="statusChart" style="margin-top:14px"></canvas></div>
  </div>
</div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
const typeData = <?= json_encode(array_column($byType,'c','fraud_type')) ?>;
const statusData = <?= json_encode(array_column($byStatus,'c','status')) ?>;
const cyan='#00ffc2', palette=['#00ffc2','#37a2ff','#ffcf6b','#ff4757','#a78bfa','#5dcaa5','#f0997b'];
function mk(id,type,obj){
  const labels=Object.keys(obj).map(k=>k.replace(/_/g,' '));
  new Chart(document.getElementById(id),{type:type,
    data:{labels:labels,datasets:[{data:Object.values(obj),backgroundColor:palette,borderColor:'#0f1521',borderWidth:2}]},
    options:{plugins:{legend:{labels:{color:'#e8ecf1'}}},scales:type==='bar'?{x:{ticks:{color:'#7686a8'}},y:{ticks:{color:'#7686a8'}}}:{}}});
}
if(Object.keys(typeData).length) mk('typeChart','doughnut',typeData); else document.getElementById('typeChart').replaceWith('No data yet');
if(Object.keys(statusData).length) mk('statusChart','bar',statusData); else document.getElementById('statusChart').replaceWith('No data yet');
</script>
