<?php
/** CYBRON — Case Room (Final & Production Hardened) */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_active();

$caseId = (int)($_GET['id'] ?? 0);
if (!$caseId || !can_access_case($caseId)) {
    http_response_code(403);
    exit('Unauthorized access attempt.');
}

$me = current_user();

// Fetch Data
try {
    $stmt = db()->prepare('SELECT c.*, u.name AS victim_name FROM cases c JOIN users u ON u.id=c.victim_id WHERE c.id=?');
    $stmt->execute([$caseId]);
    $case = $stmt->fetch();
    if (!$case) throw new Exception('Case not found');

    $msgs = db()->prepare('SELECT m.*, u.name FROM case_messages m JOIN users u ON u.id=m.sender_id WHERE m.case_id=? ORDER BY m.created_at ASC');
    $msgs->execute([$caseId]);
    $msgs = $msgs->fetchAll() ?: [];

    $files = db()->prepare('SELECT * FROM case_files WHERE case_id=? ORDER BY created_at DESC');
    $files->execute([$caseId]);
    $files = $files->fetchAll() ?: [];

} catch (Exception $e) {
    exit('Error loading case room: ' . e($e->getMessage()));
}

$page_title = $case['case_code'];
require __DIR__ . '/includes/header.php';
?>
<section class="page">
  <div class="wrap">
    
    <?php if ($msg = get_flash()): ?>
        <div class="card" style="border:1px solid var(--cyan); margin-bottom:20px; padding:15px; color:var(--cyan)">
            <?= e($msg) ?>
        </div>
    <?php endif; ?>

    <div class="row-between">
      <div>
        <span class="pill pill-cyan mono"><?= e($case['case_code']) ?></span>
        <h2 style="font-family:'Sora';font-size:26px;margin-top:8px"><?= e($case['title']) ?></h2>
        <p class="muted"><?= e(ucfirst(str_replace('_',' ',$case['fraud_type']))) ?> · ₹<?= number_format((float)$case['amount_lost']) ?> · Priority: <?= e($case['priority']) ?></p>
      </div>
      <a href="<?= e(jitsi_url($case['case_code'])) ?>" target="_blank" rel="noopener" class="btn btn-ghost">🎥 Start video meet</a>
    </div>

    <div class="grid grid-2" style="margin-top:24px;align-items:start">
      <div>
        <div class="card">
          <h3>Case Room chat</h3>
          <div class="room-chat" id="roomChat">
            <?php foreach ($msgs as $m): ?>
              <div class="chat-msg <?= $m['sender_id']==$me['id']?'chat-user':'chat-bot' ?>">
                  <b><?= e(explode(' ',$m['name'])[0]) ?>:</b> <?= e($m['body']) ?>
              </div>
            <?php endforeach; ?>
          </div>
          <div class="chat-input-row" style="padding:0">
            <textarea id="roomInput" rows="1" placeholder="Message the case room…"></textarea>
            <button id="roomSend" class="btn btn-primary">Send</button>
          </div>
        </div>

        <div class="card" style="margin-top:16px">
          <h3>🤖 AI tools</h3>
          <div class="kard-actions" style="margin-top:12px;flex-wrap:wrap">
            <button class="btn btn-ghost" data-ai="summary">Summarise</button>
            <button class="btn btn-ghost" data-ai="draft">Complaint draft</button>
            <button class="btn btn-ghost" data-ai="legal">Legal sections</button>
          </div>
          <div id="aiOut" style="margin-top:14px;white-space:pre-wrap;font-size:14px;display:none;background:var(--void);border:1px solid var(--border);border-radius:10px;padding:14px"></div>
        </div>
      </div>

      <div>
        <div class="card">
          <h3>Status</h3>
          <select id="statusSel" style="margin-top:10px">
            <?php foreach (['open','triage','in_progress','escalated','resolved','closed'] as $s): ?>
              <option value="<?= $s ?>" <?= $case['status']===$s?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="card" style="margin-top:16px">
          <h3>Evidence</h3>
          <form id="fileForm" enctype="multipart/form-data" style="margin-top:10px">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="file" id="fileInput" name="file" required>
            <button class="btn btn-ghost btn-block" style="margin-top:8px" type="submit">Upload</button>
          </form>
          <div style="margin-top:10px">
            <?php foreach ($files as $f): ?>
              <a href="<?= e(BASE_URL.'/'.$f['file_path']) ?>" target="_blank" class="pill pill-cyan" style="margin:0 6px 6px 0">📎 <?= e($f['file_name']) ?></a>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>

<script>
  window.CYBRON = {
    caseId: <?= (int)$caseId ?>,
    csrf: "<?= e(csrf_token()) ?>",
    me: "<?= e(explode(' ', $me['name'])[0]) ?>",
    // Mapping to /api folder files
    api: "api/case-action.php",
    upload: "api/case-upload.php",
    aiSummary: "api/ai-summary.php",
    aiDraft: "api/ai-draft.php",
    aiLegal: "api/ai-legal.php",
    // AI context
    amount: <?= (float)$case['amount_lost'] ?>,
    ftype: "<?= e($case['fraud_type']) ?>",
    desc: "<?= e($case['description'] ?? '') ?>"
  };
</script>
<script src="<?= e(BASE_URL) ?>/assets/js/case.js"></script>