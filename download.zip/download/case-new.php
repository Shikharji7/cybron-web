<?php
/** CYBRON — Open a new case (Hardened) */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_active();
$me = current_user();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        $error = 'Session expired, please try again.';
    } else {
        $title = trim($_POST['title'] ?? '');
        $type  = $_POST['fraud_type'] ?? 'other';
        $amt   = (float)($_POST['amount'] ?? 0);
        $desc  = trim($_POST['description'] ?? '');
        $prio  = $_POST['priority'] ?? 'medium';
        
        $valid_types = ['upi_banking','otp','job','investment','identity','sim_swap','other'];
        $valid_prios = ['low','medium','high','critical'];

        // Strict Validation
        if ($title === '' || $desc === '') {
            $error = 'Title and description are required.';
        } elseif (strlen($title) > 255 || strlen($desc) > 5000) {
            $error = 'Input exceeds maximum character limit.';
        } elseif ($amt < 0) {
            $error = 'Invalid amount.';
        } else {
            if (!in_array($type, $valid_types, true)) $type = 'other';
            if (!in_array($prio, $valid_prios, true)) $prio = 'medium';
            
            $code = next_case_code();
            
            db()->prepare('INSERT INTO cases (case_code, victim_id, title, fraud_type, amount_lost, description, priority)
                           VALUES (?,?,?,?,?,?,?)')
                ->execute([$code, $me['id'], $title, $type, $amt, $desc, $prio]);
            
            $caseId = (int)db()->lastInsertId();
            case_event($caseId, 'report_filed', 'Case opened by victim');
            audit('case_create', "Code: {$code} | ID: {$caseId}");
            
            $_SESSION['flash'] = 'Case opened successfully.';
            redirect(BASE_URL . '/case.php?id=' . $caseId);
        }
    }
}

$page_title = 'Open a case';
require __DIR__ . '/includes/header.php';
?>
<section class="page">
  <div class="wrap" style="max-width:680px">
    <div class="section-head" style="text-align:left">
      <span class="section-tag">[ NEW CASE ]</span>
      <h2 style="font-size:28px">Report a fraud</h2>
      <p>Describe what happened. Using the AI assist helps us categorize and respond faster.</p>
    </div>

    <?php if ($error): ?>
        <div class="card" style="border:1px solid var(--red); color:var(--red); margin-bottom:20px; padding:15px">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <div class="ai-check" style="margin-bottom:20px">
      <h3>🤖 AI assist (optional)</h3>
      <p class="hint">Paste your incident details here and let AI extract key info.</p>
      <textarea id="aiDesc" rows="3" placeholder="Kya hua tha…"></textarea>
      <button id="aiCheckBtn" class="btn btn-ghost btn-block" style="margin-top:12px" data-fill="1">Analyse →</button>
      <div class="ai-result" id="aiResult">
        <div class="ai-badges" id="aiBadges"></div>
        <p id="aiSummary" style="margin-top:10px;font-size:14px"></p>
        <ul class="ai-steps" id="aiSteps"></ul>
      </div>
    </div>

    <form method="post" class="card" style="max-width:none">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      
      <label for="title">CASE TITLE</label>
      <input type="text" id="title" name="title" required maxlength="255">
      
      <label for="fraud_type">FRAUD TYPE</label>
      <select id="fraud_type" name="fraud_type">
        <option value="upi_banking">UPI / Banking</option>
        <option value="otp">OTP fraud</option>
        <option value="job">Job fraud</option>
        <option value="investment">Investment scam</option>
        <option value="identity">Identity theft</option>
        <option value="sim_swap">SIM swap</option>
        <option value="other" selected>Other</option>
      </select>
      
      <label for="amount">AMOUNT LOST (₹)</label>
      <input type="number" id="amount" name="amount" min="0" placeholder="0">
      
      <label for="priority">PRIORITY</label>
      <select id="priority" name="priority">
        <option value="low">Low</option>
        <option value="medium" selected>Medium</option>
        <option value="high">High</option>
        <option value="critical">Critical</option>
      </select>
      
      <label for="description">WHAT HAPPENED</label>
      <textarea id="description" name="description" required rows="6" maxlength="5000"></textarea>
      
      <button type="submit" class="btn btn-primary btn-lg btn-block" style="margin-top:18px">Open case →</button>
    </form>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
<script>
  window.CYBRON_TRIAGE_API = "<?= e(BASE_URL) ?>/api/ai-triage.php";
</script>