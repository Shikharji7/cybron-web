/* CYBRON — Kanban Board (Hardened & UX Optimized) */
(function () {
  var B = window.CYBRON_BOARD; 
  if (!B) return;

  async function post(body) {
    try {
      var r = await fetch(B.api, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      return await r.json();
    } catch (e) {
      return { error: 'Connection failed' };
    }
  }

  var addBtn = document.getElementById('addCard');
  var inp = document.getElementById('newCard');

  // Add Card Action
  if (addBtn) {
    addBtn.addEventListener('click', async function() {
      var v = (inp.value || '').trim();
      
      // Client-side length validation
      if (!v) return;
      if (v.length > 200) {
        alert('Title too long!');
        return;
      }

      addBtn.disabled = true; // Prevent double clicks
      addBtn.textContent = 'Adding...';

      var r = await post({
        action: 'add_card', 
        board_id: B.id, 
        title: v, 
        csrf: B.csrf
      });

      if (r.ok) {
        inp.value = ''; // Clear input
        location.reload(); // Refresh to show new card
      } else {
        alert(r.error || 'Failed to add card');
        addBtn.disabled = false;
        addBtn.textContent = 'Add Task';
      }
    });
  }

  // Move Card Action
  document.querySelectorAll('[data-move]').forEach(function(btn) {
    btn.addEventListener('click', async function() {
      btn.disabled = true; // Prevent double clicks
      
      var r = await post({
        action: 'move_card', 
        card_id: btn.dataset.move, 
        column: btn.dataset.to, 
        csrf: B.csrf
      });

      if (r.ok) {
        location.reload();
      } else {
        alert(r.error || 'Failed to move');
        btn.disabled = false;
      }
    });
  });
})();