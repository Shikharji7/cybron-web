/* CYBRON — shared front-end JS */
(function () {
  'use strict';

  var toggle   = document.getElementById('chatToggle');
  var panel    = document.getElementById('chatPanel');
  var closeBtn = document.getElementById('chatClose');
  var input    = document.getElementById('chatInput');
  var sendBtn  = document.getElementById('chatSend');
  var messages = document.getElementById('chatMessages');
  if (!toggle || !panel) return;

  var API = window.CYBRON_CHAT_API || 'https://cybron-api.onrender.com/chat.php';

  function addMsg(text, who) {
    var div = document.createElement('div');
    div.className = 'chat-msg ' + (who === 'user' ? 'chat-user' : 'chat-bot');
    div.textContent = text;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
    return div;
  }

  function openChat() {
    var hidden = window.getComputedStyle(panel).display === 'none';
    if (hidden) {
      panel.style.setProperty('display', 'flex', 'important');
    } else {
      panel.style.setProperty('display', 'none', 'important');
    }
    if (hidden && messages.children.length === 0) {
      addMsg('Namaste! Main CyberRakshak AI hoon. \uD83D\uDEE1\uFE0F\n\nCybron par aapka swagat hai. Kya aapke saath koi fraud hua hai?', 'bot');
    }
  }

  toggle.addEventListener('click', openChat);
  closeBtn && closeBtn.addEventListener('click', openChat);

  async function send() {
    var val = (input.value || '').trim();
    if (!val) return;
    addMsg(val, 'user');
    input.value = '';
    var loader = addMsg('CyberRakshak is typing…', 'bot');
    loader.style.opacity = '.5';
    try {
      var res = await fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: val })
      });
      var data = await res.json();
      loader.remove();
      addMsg(data.reply || data.error || 'Try again, ya call 1930.', 'bot');
    } catch (e) {
      loader.remove();
      addMsg('Network issue. Urgent ho to 1930 par call karein.', 'bot');
    }
  }

  sendBtn && sendBtn.addEventListener('click', send);
  input && input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
  });
})();

/* ---- AI fraud check (landing) ---- */
(function () {
  var btn = document.getElementById('aiCheckBtn');
  if (!btn) return;
  var API = window.CYBRON_TRIAGE_API || 'https://cybron-api.onrender.com/ai-triage.php';

  function pill(text, kind) {
    var span = document.createElement('span');
    var cls = kind === 'critical' || kind === 'high' ? 'pill-red'
            : kind === 'medium' ? 'pill-amber' : 'pill-cyan';
    span.className = 'pill ' + cls;
    span.textContent = text;
    return span;
  }

  btn.addEventListener('click', async function () {
    var desc = (document.getElementById('aiDesc').value || '').trim();
    var amt  = document.getElementById('aiAmt').value || 0;
    if (!desc) { document.getElementById('aiDesc').focus(); return; }

    var result = document.getElementById('aiResult');
    var badges = document.getElementById('aiBadges');
    var summary = document.getElementById('aiSummary');
    var steps = document.getElementById('aiSteps');
    btn.disabled = true; btn.textContent = 'Analysing…';
    badges.innerHTML = ''; steps.innerHTML = ''; summary.textContent = '';

    try {
      var res = await fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: desc, amount: Number(amt) })
      });
      var d = await res.json();
      if (d.error) { summary.textContent = d.error; result.classList.add('show'); return; }

      if (d.fraud_type) badges.appendChild(pill(String(d.fraud_type).replace(/_/g, ' '), 'info'));
      if (d.priority)   badges.appendChild(pill('priority: ' + d.priority, d.priority));
      if (d.call_1930)  badges.appendChild(pill('CALL 1930 NOW', 'critical'));
      summary.textContent = d.summary || '';
      (d.steps || []).forEach(function (s) {
        var li = document.createElement('li'); li.textContent = s; steps.appendChild(li);
      });
      result.classList.add('show');

      if (btn.dataset.fill) {
        var ft = document.getElementById('fraud_type');
        var pr = document.getElementById('priority');
        var de = document.getElementById('description');
        if (ft && d.fraud_type) ft.value = d.fraud_type;
        if (pr && d.priority)   pr.value = d.priority;
        if (de && !de.value)    de.value = desc;
      }
    } catch (e) {
      summary.textContent = 'AI busy. Urgent ho to 1930 par call karein.';
      result.classList.add('show');
    } finally {
      btn.disabled = false; btn.textContent = 'Analyse with AI →';
    }
  });
})();

/* ---- mobile nav toggle ---- */
(function () {
  var t = document.getElementById('navToggle');
  var l = document.getElementById('navLinks');
  if (t && l) t.addEventListener('click', function () { l.classList.toggle('open'); });
})();

/* ============================================================
   PREMIUM POLISH — scroll reveal, progress bar, back-to-top
   ============================================================ */
(function () {
  'use strict';

  // ---- auto-tag sections/cards/grids for scroll-reveal ----
  document.querySelectorAll('section.block, .hero, .ticker-wrap').forEach(function (el) {
    el.classList.add('reveal');
  });
  document.querySelectorAll('.grid').forEach(function (el) {
    el.classList.add('reveal-stagger');
  });

  // ---- intersection observer for reveal ----
  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.reveal, .reveal-stagger').forEach(function (el) {
      observer.observe(el);
    });
  } else {
    document.querySelectorAll('.reveal, .reveal-stagger').forEach(function (el) {
      el.classList.add('visible');
    });
  }

  // ---- scroll progress bar ----
  var progress = document.createElement('div');
  progress.id = 'scrollProgress';
  document.body.appendChild(progress);

  // ---- back-to-top button ----
  var topBtn = document.createElement('button');
  topBtn.id = 'backToTop';
  topBtn.setAttribute('aria-label', 'Back to top');
  topBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
  document.body.appendChild(topBtn);
  topBtn.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  var nav = document.querySelector('nav');

  function onScroll() {
    var h = document.documentElement;
    var max = h.scrollHeight - h.clientHeight;
    var pct = max > 0 ? (h.scrollTop / max) * 100 : 0;
    progress.style.width = pct + '%';

    if (h.scrollTop > 60) topBtn.classList.add('show');
    else topBtn.classList.remove('show');

    if (nav) {
      if (h.scrollTop > 10) nav.classList.add('scrolled');
      else nav.classList.remove('scrolled');
    }
  }

  var ticking = false;
  window.addEventListener('scroll', function () {
    if (!ticking) {
      window.requestAnimationFrame(function () { onScroll(); ticking = false; });
      ticking = true;
    }
  });
  onScroll();
})();

/* ---- stat count-up animation (triggers when visible) ---- */
(function () {
  var nums = document.querySelectorAll('.num[data-count]');
  if (!nums.length) return;

  function animate(el) {
    var target = parseInt(el.getAttribute('data-count'), 10) || 0;
    var start = 0;
    var duration = 1200;
    var startTime = null;

    function step(ts) {
      if (!startTime) startTime = ts;
      var progress = Math.min((ts - startTime) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3);
      var current = Math.floor(start + (target - start) * eased);
      el.textContent = current.toLocaleString('en-IN') + (el.dataset.suffix || '');
      if (progress < 1) window.requestAnimationFrame(step);
      else el.textContent = target.toLocaleString('en-IN') + (el.dataset.suffix || '');
    }
    window.requestAnimationFrame(step);
  }

  if ('IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animate(entry.target);
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });
    nums.forEach(function (el) { obs.observe(el); });
  } else {
    nums.forEach(animate);
  }
})();

/* ---- bulletproof: move chat widgets to be direct body children, escaping any transformed ancestors ---- */
(function () {
  var t = document.getElementById('chatToggle');
  var p = document.getElementById('chatPanel');
  if (t && t.parentElement !== document.body) document.body.appendChild(t);
  if (p && p.parentElement !== document.body) document.body.appendChild(p);
})();
