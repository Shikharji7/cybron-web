/** CYBRON — Case Room Logic (Hardened) */
(function () {
  var C = window.CYBRON;
  if (!C) return;

  // Helper: Secure POST request
  async function post(url, body) {
    try {
      var res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      return await res.json();
    } catch (e) {
      return { error: 'Network error occurred.' };
    }
  }

  // ---- Chat Logic ----
  var chat = document.getElementById('roomChat');
  var input = document.getElementById('roomInput');
  var send = document.getElementById('roomSend');

  function addMsg(name, text, mine) {
    var d = document.createElement('div');
    d.className = 'chat-msg ' + (mine ? 'chat-user' : 'chat-bot');
    
    var b = document.createElement('b');
    b.textContent = name + ': '; 
    d.appendChild(b);
    d.appendChild(document.createTextNode(text));
    
    chat.appendChild(d);
    chat.scrollTop = chat.scrollHeight;
  }

  async function sendMsg() {
    var v = (input.value || '').trim();
    if (!v) return;
    
    send.disabled = true;
    var r = await post(C.api, { 
        action: 'message', 
        case_id: C.caseId, 
        body: v, 
        csrf: C.csrf 
    });
    
    if (r.error) {
        alert('Error: ' + r.error);
    } else {
        addMsg(C.me, v, true);
        input.value = '';
    }
    send.disabled = false;
  }

  if (send) send.addEventListener('click', sendMsg);
  if (input) input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMsg(); }
  });

  // ---- Status Update ----
  var status = document.getElementById('statusSel');
  if (status) status.addEventListener('change', async function () {
    status.disabled = true;
    var r = await post(C.api, { 
        action: 'status', 
        case_id: C.caseId, 
        status: status.value, 
        csrf: C.csrf 
    });
    if (r.error) alert('Error: ' + r.error);
    status.disabled = false;
  });

  // ---- File Upload ----
  var form = document.getElementById('fileForm');
  if (form) form.addEventListener('submit', async function (e) {
    e.preventDefault();
    var fi = document.getElementById('fileInput');
    var btn = form.querySelector('button');
    
    if (!fi.files.length) return;
    
    btn.disabled = true;
    btn.textContent = 'Uploading...';
    
    var fd = new FormData();
    fd.append('file', fi.files[0]);
    fd.append('case_id', C.caseId);
    fd.append('csrf', C.csrf);
    
    try {
        var res = await fetch(C.upload, { method: 'POST', body: fd });
        var r = await res.json();
        if (r.ok) {
            location.reload(); 
        } else {
            alert(r.error || 'Upload failed.');
        }
    } catch (e) {
        alert('Upload failed: Connection error.');
    }
    btn.disabled = false;
    btn.textContent = 'Upload';
  });

  // ---- AI Tools ----
  var out = document.getElementById('aiOut');
  document.querySelectorAll('[data-ai]').forEach(function (b) {
    b.addEventListener('click', async function () {
      var kind = b.dataset.ai;
      
      // Mapping to actual file paths in your /api folder
      var endpoints = {
        'summary': C.aiSummary,
        'draft': C.aiDraft,
        'legal': C.aiLegal
      };
      
      var endpoint = endpoints[kind];
      if (!endpoint) return;

      out.style.display = 'block';
      out.textContent = '🤖 AI processing...';
      
      var payload = { case_id: C.caseId, csrf: C.csrf };
      if (kind === 'draft') {
          payload.amount = C.amount;
          payload.ftype = C.ftype;
      } else if (kind === 'legal') {
          payload.desc = C.desc;
      }
      
      var r = await post(endpoint, payload);
      out.textContent = r.summary || r.draft || r.reply || r.error || 'No result available.';
    });
  });
})();