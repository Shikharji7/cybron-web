<?php
/** CYBRON — Secure Logout */
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';

// 1. Session start karo agar nahi hai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Session data clear karo
$_SESSION = [];

// 3. Browser ki session cookie ko delete/expire karo
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// 4. Session destroy karo
session_destroy();

// 5. Redirect
header('Location: ' . BASE_URL . '/index.php');
exit;