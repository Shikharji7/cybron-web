<?php
/** CYBRON — first-time role selection */
declare(strict_types=1);
require_once __DIR__ . '/../includes/functions.php';
require_login();

$me = current_user();
if (!empty($me['role'])) {
    redirect(BASE_URL . '/dashboard.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        $error = 'Session expired, please retry.';
    } else {
        $role = $_POST['role'] ?? '';
        $org  = trim($_POST['organisation'] ?? '');
        if (!array_key_exists($role, ROLES)) {
            $error = 'Please choose a valid role.';
        } else {
            $status = in_array($role, INSTANT_ROLES, true) ? 'active' : 'pending';
            db()->prepare('UPDATE users SET role=?, organisation=?, verification_status=? WHERE id=?')
                ->execute([$role, $org ?: null, $status, $me['id']]);
            if ($status === 'pending') {
                db()->prepare('INSERT INTO verification_requests (user_id, role) VALUES (?,?)')
                    ->execute([$me['id'], $role]);
            }
            redirect(BASE_URL . '/dashboard.php');
        }
    }
}

$page_title = 'Choose your role';
require __DIR__ . '/../includes/header.php';
?>
<section class="block">
  <div class="wrap">
    <div class="section-head">
      <span class="section-tag">[ ONBOARDING ]</span>
      <h2>Who are you on Cybron?</h2>
      <p>Pick the seat you hold. Victims get instant access; advocates, police, banks and others are verified before going live — so every badge is real.</p>
    </div>
    <form method="post" class="form-card">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <?php if ($error): ?><p class="pill pill-red" style="margin-bottom:10px"><?= e($error) ?></p><?php endif; ?>
      <label for="role">YOUR ROLE</label>
      <select name="role" id="role" required>
        <option value="">— select —</option>
        <?php foreach (ROLES as $key => $label): ?>
          <option value="<?= e($key) ?>"><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
      <label for="organisation">ORGANISATION (if any)</label>
      <input type="text" id="organisation" name="organisation" placeholder="Bank name, dept, firm, NGO…">
      <button type="submit" class="btn btn-primary btn-lg btn-block" style="margin-top:20px">Continue →</button>
    </form>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
