<?php
/** CYBRON — Google OAuth: Secure Callback Handler */
declare(strict_types=1);

// 1. Session start karo (safety first)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Validate state + code
if (empty($_GET['code']) || empty($_GET['state'])
    || !isset($_SESSION['oauth_state']) 
    || ($_GET['state'] !== $_SESSION['oauth_state'])) {
    exit('Security Error: Invalid OAuth state. Please try signing in again.');
}
unset($_SESSION['oauth_state']);

// 2. Exchange code for tokens (With Error Handling)
$ch = curl_init(GOOGLE_TOKEN_URL);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => http_build_query([
        'code'          => $_GET['code'],
        'client_id'     => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'redirect_uri'  => GOOGLE_REDIRECT_URI,
        'grant_type'    => 'authorization_code',
    ]),
]);

$response = curl_exec($ch);
if ($response === false) {
    exit('OAuth Error: Could not connect to Google API: ' . curl_error($ch));
}
$tokenRes = json_decode((string)$response, true);
curl_close($ch);

if (empty($tokenRes['access_token'])) {
    exit('OAuth Error: Could not get access token.');
}

// 3. Fetch user profile
$ch = curl_init(GOOGLE_USERINFO_URL);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $tokenRes['access_token']],
]);
$profile = json_decode((string)curl_exec($ch), true);
curl_close($ch);

if (empty($profile['sub']) || empty($profile['email'])) {
    exit('OAuth Error: Could not verify identity.');
}

// 4. Find or create user
$pdo  = db();
$stmt = $pdo->prepare('SELECT * FROM users WHERE google_id = ? LIMIT 1');
$stmt->execute([$profile['sub']]);
$user = $stmt->fetch();

// --- SECURITY FIX: Session Fixation Protection ---
session_regenerate_id(true); 

if ($user) {
    $pdo->prepare('UPDATE users SET name=?, avatar=?, last_login_at=NOW() WHERE id=?')
        ->execute([$profile['name'] ?? $user['name'], $profile['picture'] ?? null, $user['id']]);
    $_SESSION['user_id'] = (int)$user['id'];
} else {
    $pdo->prepare('INSERT INTO users (google_id, email, name, avatar, last_login_at) VALUES (?,?,?,?,NOW())')
        ->execute([
            $profile['sub'],
            $profile['email'],
            $profile['name'] ?? 'Cybron User',
            $profile['picture'] ?? null,
        ]);
    $_SESSION['user_id'] = (int)$pdo->lastInsertId();
}

// 5. Route: pick a role if none yet, else dashboard
$me = current_user(); // Ensure current_user() works after session_regenerate_id
if (empty($me['role'])) {
    redirect(BASE_URL . '/auth/select-role.php');
}
redirect(BASE_URL . '/dashboard.php');