<?php
/** CYBRON — Book a free consultation (Hardened) */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_active();
$me = current_user();

// Flash Messages
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        $_SESSION['flash'] = 'Error: Session expired.';
    } else {
        $contact = trim($_POST['contact'] ?? '');
        $fraud_type = $_POST['fraud_type'] ?? 'Other';
        $slot = $_POST['slot'] ?? '10:00';
        $notes = trim($_POST['notes'] ?? '');
        
        // Validation
        if ($contact === '') {
            $_SESSION['flash'] = 'Error: Contact information is required.';
        } elseif (strlen($contact) > 100 || strlen($notes) > 2000) {
            $_SESSION['flash'] = 'Error: Input exceeds allowed length.';
        } else {
            $adv = (int)($_POST['advocate_id'] ?? 0) ?: null;
            
            // Insert
            $stmt = db()->prepare('INSERT INTO consultations (user_id, advocate_id, contact, fraud_type, notes, slot_time) VALUES (?,?,?,?,?,?)');
            $stmt->execute([$me['id'], $adv, $contact, $fraud_type, $notes, $slot]);
            
            if ($adv) {
                notify($adv, 'New consultation request', 'A victim requested a session.', '/dashboard.php');
            }
            audit('consult_book');
            
            $_SESSION['flash'] = '✅ Request sent successfully. An expert will contact you soon.';
        }
    }
    // PRG Pattern: Redirect to avoid resubmission
    redirect(BASE_URL . '/book.php');
}

$advocates = db()->query("SELECT id, name, organisation, city FROM users WHERE role IN ('advocate','forensics') AND verification_status='active' ORDER BY name")->fetchAll();

$page_title = 'Book a session';
require __DIR__ . '/includes/header.php';
?>
<section class="page">
  <div class="wrap" style="max-width:640px">
    
    <?php if ($flash): ?>
        <div class="card" style="border:1px solid var(--cyan); margin-bottom:20px; padding:15px; color:var(--cyan)">
            <?= e($flash) ?>
        </div>
    <?php endif; ?>

    <div class="section-head" style="text-align:left">
      <span class="section-tag">[ CONSULTATION · FREE ]</span>
      <h2 style="font-size:28px">Book an advocate or expert</h2>
      <p>30-minute free video/call consultation. No fees, ever.</p>
    </div>

    <form method="post" class="card" style="max-width:none">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      
      <label>PREFERRED ADVOCATE / EXPERT (optional)</label>
      <select name="advocate_id">
        <option value="">Any available</option>
        <?php foreach ($advocates as $a): ?>
            <option value="<?= e((string)$a['id']) ?>"><?= e($a['name']) ?><?= $a['city']?' · '.e($a['city']):'' ?></option>
        <?php endforeach; ?>
      </select>
      
      <label>PHONE OR EMAIL</label>
      <input name="contact" required placeholder="9999999999 or you@email.com" maxlength="100">
      
      <label>TYPE OF FRAUD</label>
      <select name="fraud_type">
        <option>UPI / Banking</option><option>OTP</option><option>Job</option>
        <option>Investment</option><option>Identity</option><option>SIM swap</option>
        <option>Other</option>
      </select>
      
      <label>PREFERRED SLOT</label>
      <select name="slot">
        <option>10:00</option><option>12:30</option><option>14:00</option>
        <option>17:00</option><option>18:30</option><option>19:00</option>
      </select>
      
      <label>BRIEF DESCRIPTION</label>
      <textarea name="notes" placeholder="What happened, in a few lines" maxlength="2000"></textarea>
      
      <button class="btn btn-primary btn-lg btn-block" style="margin-top:18px">Confirm booking →</button>
    </form>
    
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>