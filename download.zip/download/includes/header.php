<?php
// Fix: Handle cases where functions.php might not define these
if (!defined('BRAND_NAME')) define('BRAND_NAME', 'Cybron');
if (!defined('BRAND_TAGLINE')) define('BRAND_TAGLINE', 'Empowering cyber defense against fraud through advanced threat intelligence and real-time monitoring.');
if (!defined('BASE_URL')) define('BASE_URL', 'https://cybron.in');

require_once __DIR__ . '/functions.php';
$u = current_user();
$page_title = isset($page_title) ? $page_title : BRAND_NAME;

// Current URL generator for SEO tags
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
$current_url = $protocol . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

// Current page detector
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="referrer" content="strict-origin-when-cross-origin">
    
    <link rel="canonical" href="<?= e($current_url) ?>">
    
    <title><?= e($page_title) ?> — <?= e(BRAND_NAME) ?></title>
    <meta name="description" content="<?= e(BRAND_TAGLINE) ?> A comprehensive cyber security platform by Tech Eagles, under Mahakumbrix Innovation.">
    
    <meta name="author" content="<?= e(BRAND_NAME) ?>">
    <meta property="article:author" content="<?= e(BRAND_NAME) ?>">

    <meta property="og:title" content="<?= e($page_title) ?> — <?= e(BRAND_NAME) ?>">
    <meta property="og:description" content="<?= e(BRAND_TAGLINE) ?> A comprehensive cyber security platform by Tech Eagles.">
    <meta property="og:url" content="<?= e($current_url) ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?= e(BRAND_NAME) ?>">
    <meta property="og:locale" content="en_IN">
    
    <meta property="og:image" content="<?= e(BASE_URL) ?>/assets/social-preview.jpg">
    <meta property="og:image:secure_url" content="<?= e(BASE_URL) ?>/assets/social-preview.jpg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:type" content="image/jpeg">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($page_title) ?> — <?= e(BRAND_NAME) ?>">
    <meta name="twitter:description" content="<?= e(BRAND_TAGLINE) ?>">
    <meta name="twitter:image" content="<?= e(BASE_URL) ?>/assets/social-preview.jpg">

    <link rel="apple-touch-icon" sizes="180x180" href="<?= e(BASE_URL) ?>/assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?= e(BASE_URL) ?>/assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?= e(BASE_URL) ?>/assets/favicon-16x16.png">
    <link rel="manifest" href="<?= e(BASE_URL) ?>/assets/site.webmanifest">

    <script type="application/ld+json">
    {
        "@context": "https://schema.org/",
        "@type": "Organization",
        "name": "<?= e(BRAND_NAME) ?>",
        "url": "<?= e(BASE_URL) ?>/",
        "logo": "<?= e(BASE_URL) ?>/assets/logo.png",
        "description": "<?= e(BRAND_TAGLINE) ?>"
    }
    </script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
    <meta name="theme-color" content="#0f1521">

    <style>
        .nav-links select, .nav-links .lang-select { 
            background: rgba(255,255,255,0.06); border: 1px solid var(--border, #2a3448); 
            color: var(--text, #e8edf5); padding: 6px 32px 6px 14px; border-radius: 30px; 
            font-size: 0.85rem; font-weight: 500; cursor: pointer; outline: none; 
            font-family: 'Inter', sans-serif; transition: all 0.2s ease; appearance: none; 
            -webkit-appearance: none; 
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%238b9ab0' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E"); 
            background-repeat: no-repeat; background-position: right 12px center; 
        }
        .nav-links select:hover, .nav-links .lang-select:hover { border-color: var(--cyan, #00c8ff); background-color: rgba(255,255,255,0.1); }
        .nav-links a.active { color: var(--cyan, #00c8ff) !important; font-weight: 600; position: relative; }
        .nav-links a.active::after { content: ''; position: absolute; bottom: -4px; left: 0; width: 100%; height: 2px; background-color: var(--cyan, #00c8ff); border-radius: 2px; }
        @media (max-width: 768px) { .nav-links select, .nav-links .lang-select { font-size: 0.75rem; padding: 4px 28px 4px 10px; background-size: 10px; background-position: right 8px center; } }
    </style>
</head>
<body>
    <div class="particles" aria-hidden="true">
        </div>

    <nav>
        <a href="<?= e(BASE_URL) ?>/index.php" class="logo">
            <span class="logo-mark"></span><?= strtoupper(e(BRAND_NAME)) ?>
        </a>
        <button id="navToggle" class="nav-toggle" aria-label="Menu">☰</button>
        <div class="nav-links" id="navLinks">
            <?php require __DIR__ . '/translate.php'; ?>
            
            <a href="<?= e(BASE_URL) ?>/directory.php" class="<?= $current_page === 'directory.php' ? 'active' : '' ?>">Directory</a>
            <a href="<?= e(BASE_URL) ?>/encyclopedia.php" class="<?= $current_page === 'encyclopedia.php' ? 'active' : '' ?>">Scam wiki</a>
            <a href="<?= e(BASE_URL) ?>/scam-checker.php" class="<?= $current_page === 'scam-checker.php' ? 'active' : '' ?>">Scam check</a>
            <a href="<?= e(BASE_URL) ?>/stats.php" class="<?= $current_page === 'stats.php' ? 'active' : '' ?>">Stats</a>
            
            <?php if ($u): ?>
                <a href="<?= e(BASE_URL) ?>/warroom.php" class="<?= $current_page === 'warroom.php' ? 'active' : '' ?>">War Room</a>
                <a href="<?= e(BASE_URL) ?>/dashboard.php" class="<?= $current_page === 'dashboard.php' ? 'active' : '' ?>">Dashboard</a>
                <a href="<?= e(BASE_URL) ?>/profile.php" class="<?= $current_page === 'profile.php' ? 'active' : '' ?>">Profile</a> 
                
                <?php if (($u['role'] ?? '') === 'admin'): ?>
                    <a href="<?= e(BASE_URL) ?>/admin.php" class="<?= $current_page === 'admin.php' ? 'active' : '' ?>" style="color:var(--cyan)">Admin</a>
                <?php endif; ?>
                
                <div class="nav-user">
                    <?php if (!empty($u['avatar'])): ?><img src="<?= e($u['avatar']) ?>" alt=""><?php endif; ?>
                    <a href="<?= e(BASE_URL) ?>/auth/logout.php">Logout</a>
                </div>
            <?php else: ?>
                <a href="<?= e(BASE_URL) ?>/auth/google-login.php" class="btn btn-primary">Sign in</a>
            <?php endif; ?>
        </div>
    </nav>