<?php require_once __DIR__ . '/../config/config.php'; ?>

<div class="gt-wrap notranslate" title="Choose language">
  <span class="gt-globe" aria-hidden="true">🌐</span>
  <select id="customLangSelect" class="custom-lang-select">
    <option value="en">English</option>
    <?php
    $langs = defined('INDIAN_LANGUAGES') ? explode(',', INDIAN_LANGUAGES) : 
      ['hi','bn','ta','te','ml','kn','gu','mr','pa','or','as','ne','ur','sa','si','ma','doi','mni','sd'];
    $langNames = [
      'hi' => 'हिंदी (Hindi)', 'bn' => 'বাংলা (Bengali)', 'ta' => 'தமிழ் (Tamil)', 'te' => 'తెలుగు (Telugu)',
      'ml' => 'മലയാളം (Malayalam)', 'kn' => 'ಕನ್ನಡ (Kannada)', 'gu' => 'ગુજરાતી (Gujarati)', 'mr' => 'मराठी (Marathi)',
      'pa' => 'ਪੰਜਾਬੀ (Punjabi)', 'or' => 'ଓଡ଼ିଆ (Odia)', 'as' => 'অসমীয়া (Assamese)', 'ne' => 'नेपाली (Nepali)',
      'ur' => 'اردو (Urdu)', 'sa' => 'संस्कृत (Sanskrit)', 'si' => 'සිංහල (Sinhala)', 'ma' => 'मैथिली (Maithili)',
      'doi' => 'डोगरी (Dogri)', 'mni' => 'মৈতৈলোন্ (Meiteilon)', 'sd' => 'سنڌي (Sindhi)'
    ];
    foreach ($langs as $code) {
      $code = trim($code);
      if ($code && isset($langNames[$code])) {
        echo '<option value="' . $code . '">' . $langNames[$code] . '</option>';
      }
    }
    ?>
  </select>
</div>

<div id="google_translate_element" style="display:none;"></div>

<style>
  body { top: 0 !important; }
  .goog-te-banner-frame { display: none !important; }
  #goog-gt-tt { display: none !important; visibility: hidden !important; }
  .goog-tooltip { display: none !important; }
  .goog-text-highlight { background-color: transparent !important; box-shadow: none !important; }

  .gt-wrap { display: inline-flex; align-items: center; gap: 6px; }
  .gt-globe { font-size: 1.1rem; opacity: 0.7; color: #8b9ab0; }
  .custom-lang-select {
    background: rgba(255,255,255,0.06); border: 1px solid #2a3448; color: #e8edf5;
    padding: 6px 32px 6px 14px; border-radius: 30px; font-size: 0.85rem; font-weight: 500;
    cursor: pointer; outline: none; appearance: none; -webkit-appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%238b9ab0' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");
    background-repeat: no-repeat; background-position: right 12px center;
    background-size: 12px; transition: all 0.2s ease; max-width: 160px;
  }
  .custom-lang-select:hover { border-color: #00c8ff; background-color: rgba(255,255,255,0.12); }
  .custom-lang-select option { background: #1a2233 !important; color: #e8edf5 !important; padding: 8px 12px !important; }
</style>

<script>
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: 'en',
    includedLanguages: '<?= defined('INDIAN_LANGUAGES') ? INDIAN_LANGUAGES : 'en,hi,bn,ta,te,ml,kn,gu,mr,pa,or,as,ne,ur,sa,si,ma,doi,mni,sd' ?>',
    autoDisplay: false
  }, 'google_translate_element');
}

// Robust trigger function
function changeGoogleLanguage(langCode) {
    var googleSelect = document.querySelector('.goog-te-combo');
    if (googleSelect) {
        googleSelect.value = langCode;
        googleSelect.dispatchEvent(new Event('change'));
        googleSelect.dispatchEvent(new Event('click')); // Some browsers need click
        localStorage.setItem('cybron_active_lang', langCode);
        return true;
    }
    return false;
}

document.addEventListener('DOMContentLoaded', function() {
  var customSelect = document.getElementById('customLangSelect');
  
  // 1. Handle selection
  customSelect.addEventListener('change', function() {
    changeGoogleLanguage(this.value);
  });

  // 2. Loop until Google Widget appears (fixes loading delay)
  var retryCount = 0;
  var interval = setInterval(function() {
      if (changeGoogleLanguage(localStorage.getItem('cybron_active_lang') || 'en')) {
          customSelect.value = localStorage.getItem('cybron_active_lang') || 'en';
          clearInterval(interval);
      }
      if (++retryCount > 20) clearInterval(interval); // Stop after 10 seconds
  }, 500);
});
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" defer></script>