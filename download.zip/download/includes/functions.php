<?php
/**
 * CYBRON — Shared Helpers (Security Hardened & Optimized)
 */
declare(strict_types=1);

// Set timezone for consistent logs/data
date_default_timezone_set('Asia/Kolkata');

// 1. SECURITY: Headers
if (!headers_sent()) {
    header("X-Frame-Options: SAMEORIGIN");
    header("X-XSS-Protection: 1; mode=block");
    header("X-Content-Type-Options: nosniff");
    header("Strict-Transport-Security: max-age=31536000; includeSubDomains; preload");
}

// 2. SESSION SECURITY: Hardened Session Setup
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on'),
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

/** Flash Message Handler */
function flash(string $message): void {
    $_SESSION['flash'] = $message;
}

function get_flash(): ?string {
    $msg = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $msg;
}

/** Get current user */
function current_user(): ?array {
    static $user = null;
    if (empty($_SESSION['user_id'])) return null;
    if ($user === null) {
        $stmt = db()->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch() ?: null;
    }
    return $user;
}

/** Role Helpers */
function is_logged_in(): bool {
    return (bool)current_user();
}

function is_admin(): bool {
    $u = current_user();
    return $u && isset($u['role']) && $u['role'] === 'admin';
}

function require_active(): void {
    if (!is_logged_in()) redirect(BASE_URL . '/login.php');
}

// FIX: Added missing require_admin function
function require_admin(): void {
    if (!is_logged_in()) {
        redirect(BASE_URL . '/login.php');
    }
    if (!is_admin()) {
        // Agar user admin nahi hai, toh dashboard par bhej do
        redirect(BASE_URL . '/dashboard.php');
    }
}

/** CSRF Protection */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_check(?string $token): bool {
    return !empty($token) && hash_equals($_SESSION['csrf'] ?? '', $token);
}

/** Utilities */
function e(?string $s): string {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): never {
    header('Location: ' . $path);
    exit;
}

function get_client_ip(): string {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return explode(',', (string)$ip)[0];
}

function audit(string $action, ?string $detail = null): void {
    $uid = $_SESSION['user_id'] ?? null;
    db()->prepare('INSERT INTO audit_log (user_id, action, detail, ip) VALUES (?,?,?,?)')
        ->execute([$uid, $action, $detail, get_client_ip()]);
}

/** Access Control: Can the current user view/act on a case? */
function can_access_case(int $caseId): bool {
    $u = current_user();
    if (!$u) return false;
    if (is_admin()) return true;
    
    $stmt = db()->prepare(
        'SELECT 1 FROM cases c
         LEFT JOIN case_participants p ON p.case_id=c.id AND p.user_id=:uid
         WHERE c.id=:cid AND (c.victim_id=:uid OR p.user_id=:uid) LIMIT 1'
    );
    $stmt->execute([':cid' => $caseId, ':uid' => $u['id']]);
    return (bool)$stmt->fetch();
}

require_once __DIR__ . '/../config/db.php';