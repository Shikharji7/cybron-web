<footer>
  <div class="wrap">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="logo"><span class="logo-mark"></span><?= strtoupper(e(BRAND_NAME)) ?></div>
        <p>AI-driven fraud response and verified, free coordination for cybercrime victims and responders across India.</p>
        <div class="social">
          <a href="https://t.me/cybron1930" target="_blank" rel="noopener noreferrer" aria-label="Telegram Channel">
            <svg viewBox="0 0 24 24"><path d="M23.95 4.57l-3.62 17.07c-.27 1.2-.99 1.5-2 .94l-5.52-4.07-2.66 2.56c-.3.3-.54.54-1.1.54l.39-5.57L19.5 6.9c.44-.39-.1-.61-.68-.22L6.6 14.4l-5.45-1.7c-1.18-.37-1.2-1.18.25-1.75L22.43 2.7c.98-.36 1.84.22 1.52 1.87z"/></svg>
          </a>
          <a href="<?= e(SOCIAL['x']) ?>" target="_blank" rel="noopener noreferrer" aria-label="X (Twitter)">
            <svg viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24h-6.66l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231 5.45-6.231Zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77Z"/></svg>
          </a>
          <a href="<?= e(SOCIAL['instagram']) ?>" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
            <svg viewBox="0 0 24 24"><path d="M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.42.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.42.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41a3.7 3.7 0 0 1-1.38-.9 3.7 3.7 0 0 1-.9-1.38c-.16-.42-.36-1.06-.41-2.23C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.16 1.06-.36 2.23-.41C8.42 2.17 8.8 2.16 12 2.16Zm0 1.62c-3.15 0-3.51.01-4.75.07-.96.04-1.48.2-1.83.34-.46.18-.79.39-1.13.74-.35.34-.56.67-.74 1.13-.14.35-.3.87-.34 1.83-.06 1.24-.07 1.6-.07 4.75s.01 3.51.07 4.75c.04.96.2 1.48.34 1.83.18.46.39.79.74 1.13.34.35.67.56 1.13.74.35.14.87.3 1.83.34 1.24.06 1.6.07 4.75.07s3.51-.01 4.75-.07c.96-.04 1.48-.2 1.83-.34.46-.18.79-.39 1.13-.74.35-.34.56-.67.74-1.13.14-.35.3-.87.34-1.83.06-1.24.07-1.6.07-4.75s-.01-3.51-.07-4.75c-.04-.96-.2-1.48-.34-1.83a3.04 3.04 0 0 0-.74-1.13 3.04 3.04 0 0 0-1.13-.74c-.35-.14-.87-.3-1.83-.34-1.24-.06-1.6-.07-4.75-.07Zm0 2.76a5.3 5.3 0 1 1 0 10.6 5.3 5.3 0 0 1 0-10.6Zm0 8.74a3.44 3.44 0 1 0 0-6.88 3.44 3.44 0 0 0 0 6.88Zm6.74-8.94a1.24 1.24 0 1 1-2.48 0 1.24 1.24 0 0 1 2.48 0Z"/></svg>
          </a>
          <a href="<?= e(SOCIAL['youtube']) ?>" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
            <svg viewBox="0 0 24 24"><path d="M23.5 6.2a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.51A3.02 3.02 0 0 0 .5 6.2 31.5 31.5 0 0 0 0 12a31.5 31.5 0 0 0 .5 5.8 3.02 3.02 0 0 0 2.12 2.14c1.88.51 9.38.51 9.38.51s7.5 0 9.38-.51a3.02 3.02 0 0 0 2.12-2.14A31.5 31.5 0 0 0 24 12a31.5 31.5 0 0 0-.5-5.8ZM9.6 15.57V8.43L15.8 12l-6.2 3.57Z"/></svg>
          </a>
          <a href="<?= e(SOCIAL['whatsapp']) ?>" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp Channel">
            <svg viewBox="0 0 24 24"><path d="M.06 24l1.68-6.15a11.87 11.87 0 0 1-1.6-5.95C.14 5.34 5.5 0 12.08 0a11.82 11.82 0 0 1 8.42 3.5 11.82 11.82 0 0 1 3.48 8.42c0 6.58-5.36 11.93-11.95 11.93a11.9 11.9 0 0 1-5.7-1.45L.06 24Zm6.6-3.8c1.68.99 3.28 1.59 5.42 1.59 5.46 0 9.9-4.43 9.9-9.88a9.8 9.8 0 0 0-2.9-6.99 9.8 9.8 0 0 0-6.98-2.9c-5.46 0-9.9 4.44-9.9 9.89 0 2.09.66 3.66 1.74 5.3l-.99 3.62 3.71-.97Zm11.34-5.55c-.07-.12-.27-.2-.56-.34-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.66.15-.2.3-.76.96-.93 1.16-.17.2-.34.22-.64.07-.3-.15-1.25-.46-2.39-1.47-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.61.13-.13.3-.34.45-.51.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.66-1.6-.91-2.19-.24-.57-.48-.5-.66-.5l-.56-.01c-.2 0-.51.07-.78.37-.27.3-1.02 1-1.02 2.43s1.05 2.82 1.2 3.02c.15.2 2.06 3.15 5 4.42.7.3 1.24.48 1.67.62.7.22 1.34.19 1.84.12.56-.09 1.76-.72 2-1.42.25-.7.25-1.29.18-1.42Z"/></svg>
          </a>
        </div>
      </div>
      <div class="footer-col">
        <h5>PLATFORM</h5>
        <a href="<?= e(BASE_URL) ?>/index.php#services">Services</a>
        <a href="<?= e(BASE_URL) ?>/index.php#process">How it works</a>
        <a href="<?= e(BASE_URL) ?>/dashboard.php">Dashboard</a>
      </div>
      <div class="footer-col">
        <h5>RESOURCES</h5>
        <a href="<?= e(BASE_URL) ?>/encyclopedia.php">Scam encyclopedia</a>
        <a href="<?= e(BASE_URL) ?>/guides.php">Safety guides</a>
        <a href="<?= e(BASE_URL) ?>/scam-checker.php">Scam checker</a>
        <a href="<?= e(BASE_URL) ?>/quiz.php">Awareness quiz</a>
      </div>
      <div class="footer-col">
        <h5>EMERGENCY</h5>
        <a href="tel:<?= e(CYBER_HELPLINE) ?>" style="color:var(--red)">Cyber Helpline: <?= e(CYBER_HELPLINE) ?></a>
        <a href="https://cybercrime.gov.in" target="_blank" rel="noopener noreferrer">cybercrime.gov.in</a>
        <a href="https://t.me/RakshakCyberBot" target="_blank" rel="noopener noreferrer">Telegram: @RakshakCyberBot</a>
      </div>
    </div>
    <div class="footer-bottom">
      <span><?= e(BRAND_CREDIT) ?></span>
      <span>BUILT FOR DIGITAL INDIA</span>
    </div>
  </div>
</footer>

<?php
$current_page = basename($_SERVER['PHP_SELF']);
if ($current_page !== 'quiz.php') {
    echo '<script src="' . e(BASE_URL) . '/assets/js/main.js" defer></script>';
    echo '<script>
    if ("serviceWorker" in navigator) {
      window.addEventListener("load", () => {
        navigator.serviceWorker.register("' . e(BASE_URL) . '/service-worker.js").catch(() => {});
      });
    }
    </script>';
}
?>

</body>
</html>