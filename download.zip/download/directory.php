<?php
/** CYBRON — Verified Stakeholder Directory (Optimized) */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';

$filter = $_GET['role'] ?? '';

// 1. Database Query
$sql = "SELECT name, role, organisation, city FROM users WHERE verification_status='active' AND role IS NOT NULL AND role!='victim'";
$args = [];

// Apply filter if one is selected and valid
if (!empty($filter) && in_array($filter, VERIFY_ROLES, true)) {
    $sql .= ' AND role=?';
    $args[] = $filter;
}

$sql .= ' ORDER BY role, name';

try {
    $stmt = db()->prepare($sql);
    $stmt->execute($args);
    $people = $stmt->fetchAll();
} catch (Exception $e) {
    $people = [];
    $error = $e->getMessage();
}

$page_title = 'Directory';
require __DIR__ . '/includes/header.php';
?>
<section class="page">
  <div class="wrap">
    <div class="section-head" style="text-align:left">
      <span class="section-tag">[ NETWORK ]</span>
      <h2 style="font-size:28px">Verified stakeholders</h2>
      <p>Advocates, forensics experts, cyber cells, banks and more — every badge is verified.</p>
    </div>
    
    <div class="tag-filter">
      <a href="directory.php"><button class="<?= $filter===''?'active':'' ?>">All</button></a>
      <?php if (defined('VERIFY_ROLES') && is_array(VERIFY_ROLES)): ?>
        <?php foreach (VERIFY_ROLES as $r): ?>
          <a href="?role=<?= e($r) ?>"><button class="<?= $filter===$r?'active':'' ?>"><?= e(role_label($r)) ?></button></a>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div class="grid grid-3">
      <?php if (!empty($people)): ?>
        <?php foreach ($people as $p): ?>
          <div class="card">
            <span class="pill pill-cyan"><?= e(role_label($p['role'])) ?></span>
            <h3 style="margin-top:10px"><?= e($p['name']) ?></h3>
            <p class="muted"><?= e($p['organisation'] ?: '—') ?><?= $p['city'] ? ' · '.e($p['city']) : '' ?></p>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div style="grid-column: 1/-1; padding: 40px 20px; text-align: center; border: 1px dashed var(--border); border-radius: 8px;">
            <p class="muted" style="font-size: 16px;">No verified members found<?= !empty($filter) ? ' for this category' : ' in the system yet' ?>.</p>
            <?php if (isset($error)): ?><p style="color:var(--red); margin-top: 10px;">DB Error: <?= e($error) ?></p><?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>