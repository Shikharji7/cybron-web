<?php
/** CYBRON — landing page */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';

// live-ish stats from DB (fallback to 0)
try {
    $users = (int)db()->query('SELECT COUNT(*) c FROM users')->fetch()['c'];
    $cases = (int)db()->query('SELECT COUNT(*) c FROM cases')->fetch()['c'];
    $resolved = (int)db()->query("SELECT COUNT(*) c FROM cases WHERE status='resolved'")->fetch()['c'];
    $advocates = (int)db()->query("SELECT COUNT(*) c FROM users WHERE role='advocate' AND verification_status='active'")->fetch()['c'];
    $ticker = db()->query("SELECT title, severity FROM threat_intel ORDER BY created_at DESC LIMIT 10")->fetchAll();
} catch (Throwable $e) {
    $users = $cases = $resolved = $advocates = 0;
    $ticker = [];
}

$page_title = BRAND_TAGLINE;
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div class="wrap">
    <span class="status-pill"><span class="led"></span> ALL SYSTEMS OPERATIONAL · NATIONAL COORDINATION LAYER</span>
    <span class="eyebrow">CYBER SAFETY · COORDINATION · FREE</span>
    <h1>When fraud hits,<br>everyone responds <span class="accent">together</span>.</h1>
    <p class="lead">Cybron puts victims, advocates, police, banks and experts in one shared case room — and one war room to plan the fight against cybercrime. Free for all.</p>
    <div class="hero-actions">
      <?php if (is_logged_in()): ?>
        <a href="<?= e(BASE_URL) ?>/dashboard.php" class="btn btn-primary btn-lg">Go to dashboard →</a>
      <?php else: ?>
        <a href="<?= e(BASE_URL) ?>/auth/google-login.php" class="btn btn-primary btn-lg">Report a fraud →</a>
      <?php endif; ?>
      <a href="#services" class="btn btn-ghost btn-lg">How it works</a>
      <a href="<?= e(TELEGRAM_BOT) ?>" target="_blank" rel="noopener" class="btn btn-ghost btn-lg">💬 Telegram bot</a>
    </div>
  </div>
</section>

<div class="trust-bar">
  <span class="trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2 3 6v6c0 5 3.8 8.7 9 10 5.2-1.3 9-5 9-10V6l-9-4Z"/><path d="m9 12 2 2 4-4"/></svg> END-TO-END ENCRYPTED CASE DATA</span>
  <span class="trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg> REAL-TIME RESPONDER COORDINATION</span>
  <span class="trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="10" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg> ROLE-BASED ACCESS CONTROL</span>
  <span class="trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M2 12h20"/></svg> AUDIT-TRAILED CASE TIMELINE</span>
  <span class="trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9"/><path d="M3 12h18"/></svg> MULTILINGUAL · PAN-INDIA READY</span>
</div>

<?php if ($ticker): ?>
<div class="ticker-wrap">
  <div class="ticker-track">
    <?php for ($k=0; $k<2; $k++): foreach ($ticker as $t): ?>
      <span><b>● ALERT</b> &nbsp; <?= e($t['title']) ?> &nbsp;·&nbsp; <?= e(strtoupper($t['severity'])) ?></span>
    <?php endforeach; endfor; ?>
  </div>
</div>
<?php endif; ?>

<section class="block">
  <div class="wrap">
    <div class="stat-row">
      <div class="stat"><div class="num" data-count="<?= $users ?>">0</div><div class="lbl">People on board</div></div>
      <div class="stat"><div class="num" data-count="<?= $cases ?>">0</div><div class="lbl">Cases tracked</div></div>
      <div class="stat"><div class="num" data-count="<?= $advocates ?>">0</div><div class="lbl">Verified advocates</div></div>
      <div class="stat"><div class="num" data-count="<?= $resolved ?>">0</div><div class="lbl">Resolved</div></div>
    </div>
  </div>
</section>

<section class="block" id="services">
  <div class="wrap">
    <div class="section-head">
      <span class="section-tag">[ 01 — THE TABLE ]</span>
      <h2>Every stakeholder, one platform</h2>
      <p>Cyber fraud is fought by many hands. Cybron seats them together instead of in silos.</p>
    </div>
    <div class="grid grid-3">
      <div class="card"><div class="icon">🛡️</div><h3>Case Room</h3><p>One incident, one shared timeline — victim, advocate, police, bank and forensics all see the same case and act on it.</p></div>
      <div class="card"><div class="icon">⚖️</div><h3>Free legal support</h3><p>Verified cyber advocates take cases and consult — no fees, no paywall.</p></div>
      <div class="card"><div class="icon">📡</div><h3>War Room</h3><p>NGOs, educators, police and government plan campaigns, policy and threat response together.</p></div>
      <div class="card"><div class="icon">🤖</div><h3>CyberRakshak AI</h3><p>Instant Hinglish guidance the moment fraud strikes — what to do, who to call, how to file.</p></div>
      <div class="card"><div class="icon">🔎</div><h3>Threat intel</h3><p>Shared scam-pattern feed so new frauds get flagged fast across India.</p></div>
      <div class="card"><div class="icon">🎓</div><h3>Awareness</h3><p>Scam encyclopedia and safety guides to stop fraud before it happens.</p></div>
    </div>
  </div>
</section>

<section class="block" id="process">
  <div class="wrap">
    <div class="section-head">
      <span class="section-tag">[ 02 — PROCESS ]</span>
      <h2>From incident to resolution</h2>
    </div>
    <div class="grid grid-3">
      <div class="card"><h3>1 · Report</h3><p>Sign in with Google, open a case in minutes. CyberRakshak AI guides the first steps.</p></div>
      <div class="card"><h3>2 · Coordinate</h3><p>The right responders join your Case Room — advocate, cyber cell, bank nodal officer.</p></div>
      <div class="card"><h3>3 · Resolve</h3><p>Freeze, trace, file, recover — all tracked on one shared timeline until closed.</p></div>
    </div>
  </div>
</section>

<div class="mission-banner reveal">
  <div class="wrap">
    <h2>India loses thousands of crores to cyber fraud every year. Cybron exists to close the <span class="accent">response gap</span> — the hours between a victim's first call and a coordinated, professional response.</h2>
    <div class="src">ALIGNED WITH NATIONAL CYBERCRIME REPORTING &amp; RESPONSE PRIORITIES</div>
  </div>
</div>

<section class="block" id="security">
  <div class="wrap">
    <div class="section-head">
      <span class="section-tag">[ 03 — TRUST &amp; ARCHITECTURE ]</span>
      <h2>Built for institutional adoption</h2>
      <p>Designed so that a police cyber cell, a bank's fraud desk, or a national coordination body can plug in with confidence.</p>
    </div>
    <div class="sec-grid">
      <div class="sec-item">
        <h4><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2 3 6v6c0 5 3.8 8.7 9 10 5.2-1.3 9-5 9-10V6l-9-4Z"/></svg>Secure by design</h4>
        <p>Encrypted case data, hashed credentials and Google-verified sign-in keep every stakeholder's identity and evidence protected.</p>
      </div>
      <div class="sec-item">
        <h4><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="10" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>Role-based access</h4>
        <p>Victims, verified advocates, police and bank nodal officers each see only what their role in a case requires.</p>
      </div>
      <div class="sec-item">
        <h4><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M2 12h20"/></svg>Full audit trail</h4>
        <p>Every case action — report, assignment, response, closure — is timestamped on a shared, tamper-evident timeline.</p>
      </div>
      <div class="sec-item">
        <h4><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9"/><path d="M3 12h18"/></svg>Multilingual AI triage</h4>
        <p>CyberRakshak AI understands reports in major Indian languages, classifying fraud type and urgency instantly.</p>
      </div>
      <div class="sec-item">
        <h4><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>Built to scale nationally</h4>
        <p>Cloud-hosted, stateless architecture designed to onboard districts, states or a national coordination layer.</p>
      </div>
      <div class="sec-item">
        <h4><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>Real-time threat intel</h4>
        <p>Live scam-pattern feed shared across the network so emerging frauds are flagged before they spread.</p>
      </div>
    </div>
  </div>
</section>

<section class="block" id="ai-check">
  <div class="wrap">
    <div class="section-head">
      <span class="section-tag">[ AI · ANY LANGUAGE ]</span>
      <h2>Not sure if it's a scam?</h2>
      <p>Describe what happened in any Indian language. CyberRakshak AI tells you the fraud type, how urgent it is, and exactly what to do now.</p>
    </div>
    <div class="ai-check">
      <h3>🤖 AI fraud check</h3>
      <p class="hint">Free · private · works in Hindi, Tamil, Bengali, English and more.</p>
      <textarea id="aiDesc" rows="4" placeholder="e.g. Mujhe ek call aaya, unhone OTP maanga aur 25000 cut gaye…"></textarea>
      <label for="aiAmt">AMOUNT LOST (₹, optional)</label>
      <input type="number" id="aiAmt" min="0" placeholder="25000">
      <button id="aiCheckBtn" class="btn btn-primary btn-lg btn-block" style="margin-top:16px">Analyse with AI →</button>
      <div class="ai-result" id="aiResult">
        <div class="ai-badges" id="aiBadges"></div>
        <p id="aiSummary" style="margin-top:12px;font-size:15px"></p>
        <ul class="ai-steps" id="aiSteps"></ul>
      </div>
    </div>
  </div>
</section>

<section class="partner-cta">
  <div class="wrap">
    <div class="partner-card reveal">
      <span class="section-tag" style="justify-content:center;display:flex">[ FOR INSTITUTIONS ]</span>
      <h2>Built to plug into national cybercrime response.</h2>
      <p>Cybron is structured to integrate with police cyber cells, banks and a national coordination body like I4C — shared case visibility, verified responders, and a single source of truth per incident.</p>
      <div class="partner-actions">
        <a href="mailto:contact@cybron.in?subject=Institutional%20Partnership%20Inquiry" class="btn btn-primary btn-lg">Request institutional demo →</a>
        <a href="<?= e(BASE_URL) ?>/stats.php" class="btn btn-ghost btn-lg">View live platform stats</a>
      </div>
    </div>
  </div>
</section>

<div class="compliance-strip">
  <span>A TECH EAGLES PRODUCT</span>
  <span>UNDER MAHAKUMBRIX INNOVATION</span>
  <span>GOOGLE-VERIFIED IDENTITY</span>
  <span>DESIGNED FOR DIGITAL INDIA</span>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

<!-- ===== CyberRakshak chat widget ===== -->
<button id="chatToggle" aria-label="Open CyberRakshak chat" onclick="window.cybronToggle()">
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
    <path d="M12 2C6.48 2 2 6.03 2 11c0 2.7 1.2 5.1 3.1 6.8L4 21l3.9-1.3C9.2 20.5 10.6 21 12 21c5.52 0 10-4.03 10-9s-4.48-9-10-9z"/>
  </svg>
</button>

<div id="chatPanel" role="dialog" aria-label="CyberRakshak AI" class="chat-panel-hidden" style="position:fixed!important;bottom:88px!important;right:22px!important;z-index:2147483647!important;flex-direction:column;">
  <div class="chat-header">
    <div class="chat-avatar">🦅</div>
    <div class="chat-header-info">
      <div class="name">CyberRakshak AI</div>
      <div class="sub">Online</div>
    </div>
    <button id="chatClose" aria-label="Close" onclick="window.cybronClose()" style="background:none;border:none;color:var(--white);font-size:22px;cursor:pointer;padding:2px 8px;line-height:1;opacity:.8;">&#x2715;</button>
  </div>

  <!-- Language selector -->
  <div id="chatLangScreen" style="padding:18px 16px;display:flex;flex-direction:column;gap:10px;">
    <p style="color:var(--slate);font-size:12px;text-align:center;margin:0 0 6px;letter-spacing:.5px;">CHOOSE LANGUAGE / भाषा चुनें</p>
    <button onclick="window.cybronSetLang('english')" class="lang-btn">🇬🇧 English</button>
    <button onclick="window.cybronSetLang('hindi')" class="lang-btn">🇮🇳 हिंदी (Hindi)</button>
    <button onclick="window.cybronSetLang('hinglish')" class="lang-btn">👋 Hinglish (Roman)</button>
  </div>

  <!-- Main chat -->
  <div id="chatMainScreen" style="display:none;flex-direction:column;flex:1;min-height:0;">
    <div id="chatMessages" aria-live="polite"></div>
    <div class="chat-input-row">
      <textarea id="chatInput" rows="1" placeholder="Type here…" aria-label="Message" onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();window.cybronSend();}"></textarea>
      <button id="chatSend" aria-label="Send" onclick="window.cybronSend()">➤</button>
    </div>
  </div>
</div>

<style>
.lang-btn{width:100%;padding:11px;background:var(--panel-2);border:1px solid var(--border);border-radius:10px;color:var(--white);cursor:pointer;font-size:14px;transition:border-color .2s,background .2s;}
.lang-btn:hover{border-color:var(--cyan);background:rgba(0,255,194,.06);}
</style>

<script>
  window.CYBRON_CHAT_API   = "https://cybron-ai.mehrotrashikhar99.workers.dev";
  window.CYBRON_TRIAGE_API = "https://cybron-ai.mehrotrashikhar99.workers.dev";
  window.cybronLang = null;

  window.cybronToggle = function () {
    var p = document.getElementById('chatPanel');
    p.classList.toggle('chat-panel-hidden');
  };

  window.cybronClose = function () {
    document.getElementById('chatPanel').classList.add('chat-panel-hidden');
  };

  window.cybronSetLang = function (lang) {
    window.cybronLang = lang;
    document.getElementById('chatLangScreen').style.display = 'none';
    var main = document.getElementById('chatMainScreen');
    main.style.display = 'flex';

    var placeholders = {
      english:  'Ask anything — cyber fraud, scams…',
      hindi:    'कुछ भी पूछें — साइबर फ्रॉड, स्कैम्स…',
      hinglish: 'Kuch bhi pucho — cyber fraud, scams…'
    };
    var greetings = {
      english:  'Hello! I am CyberRakshak AI 🛡️\n\nWelcome to Cybron. Have you been a victim of cyber fraud? I am here to help.',
      hindi:    'नमस्ते! मैं CyberRakshak AI हूँ 🛡️\n\nCybron पर आपका स्वागت है। क्या आपके साथ साइबर फ्रॉड हुआ है?',
      hinglish: 'Namaste! Main CyberRakshak AI hoon 🛡️\n\nCybron par aapka swagat hai. Kya aapke saath koi cyber fraud hua hai? Main yahan help ke liye hoon.'
    };

    document.getElementById('chatInput').placeholder = placeholders[lang];
    var messages = document.getElementById('chatMessages');
    if (messages.children.length === 0) {
      var d = document.createElement('div');
      d.className = 'chat-msg chat-bot';
      d.textContent = greetings[lang];
      messages.appendChild(d);
      messages.scrollTop = messages.scrollHeight;
    }
  };

  window.cybronSend = function () {
    try {
      var input    = document.getElementById('chatInput');
      var messages = document.getElementById('chatMessages');
      if (!input || !messages) return;
      var val = (input.value || '').trim();
      if (!val) return;

      var langInstr = {
        english:  'IMPORTANT: Reply ONLY in English. ',
        hindi:    'IMPORTANT: Reply ONLY in Hindi (Devanagari script). ',
        hinglish: 'IMPORTANT: Reply ONLY in Hinglish (Roman Hindi-English mix). '
      };
      var prefix = window.cybronLang ? (langInstr[window.cybronLang] || '') : '';

      var userMsg = document.createElement('div');
      userMsg.className = 'chat-msg chat-user';
      userMsg.textContent = val;
      messages.appendChild(userMsg);
      input.value = '';
      messages.scrollTop = messages.scrollHeight;

      var loader = document.createElement('div');
      loader.className = 'chat-msg chat-bot';
      loader.style.opacity = '.5';
      loader.textContent = window.cybronLang === 'hindi' ? 'टाइप हो रहा है…' : 'Typing…';
      messages.appendChild(loader);
      messages.scrollTop = messages.scrollHeight;

      fetch(window.CYBRON_CHAT_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Cybron-Key': 'cybron-x9k2-secure-2026' },
        body: JSON.stringify({ message: prefix + val })
      })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        loader.textContent = data.reply || data.error || 'Try again, ya call 1930.';
        loader.style.opacity = '1';
        messages.scrollTop = messages.scrollHeight;
      })
      .catch(function () {
        var errMsgs = {
          english:  'Network issue. For urgent help call 1930.',
          hindi:    'नेटवर्क समस्या। तुरंत सहायता के लिए 1930 पर कॉल करें।',
          hinglish: 'Network issue. Urgent ho to 1930 par call karo.'
        };
        loader.textContent = errMsgs[window.cybronLang] || 'Network issue. Call 1930.';
        loader.style.opacity = '1';
        messages.scrollTop = messages.scrollHeight;
      });
    } catch (e) {
      console.error('cybronSend error:', e);
    }
  };
</script>