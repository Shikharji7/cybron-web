<?php
/** * CYBRON — War Room Kanban Board 
 * Access Controlled & Secure
 */
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_active(); // User logged in + active check
$me = current_user();

// 1. Validate ID
$boardId = (int)($_GET['id'] ?? 0);
if ($boardId <= 0) {
    exit('Invalid board ID.');
}

// 2. Fetch Board
$stmt = db()->prepare('SELECT * FROM warroom_boards WHERE id=?');
$stmt->execute([$boardId]);
$board = $stmt->fetch();

if (!$board) {
    exit('Board not found.');
}

// 3. Security: Access Control (Only members or admin)
$stmt = db()->prepare('SELECT 1 FROM warroom_board_members WHERE board_id=? AND user_id=?');
$stmt->execute([$boardId, $me['id']]);
$is_member = (bool)$stmt->fetch();

if (!$is_member && !is_admin()) {
    http_response_code(403);
    exit('Access Denied: You do not have permission to view this board.');
}

// 4. Fetch Cards
$stmt = db()->prepare('SELECT c.*, u.name as assignee_name FROM warroom_cards c LEFT JOIN users u ON u.id=c.assignee_id WHERE c.board_id=? ORDER BY c.position ASC, c.created_at ASC');
$stmt->execute([$boardId]);
$cards = $stmt->fetchAll();

// Grouping logic
$cols = ['todo' => [], 'in_progress' => [], 'done' => []];
foreach ($cards as $c) {
    if (array_key_exists($c['column_name'], $cols)) {
        $cols[$c['column_name']][] = $c;
    }
}

$page_title = $board['title'];
require __DIR__ . '/includes/header.php';
?>

<section class="page">
  <div class="wrap">
    <a href="<?= e(BASE_URL) ?>/warroom.php" class="muted">← Back to War Room</a>
    
    <div class="row-between" style="margin-top:8px">
      <div>
        <span class="pill pill-cyan"><?= e($board['kind']) ?></span>
        <h2 style="font-family:'Sora';font-size:26px;margin-top:8px"><?= e($board['title']) ?></h2>
      </div>
    </div>

    <div style="margin-top:18px;display:flex;gap:8px;flex-wrap:wrap">
      <input id="newCard" placeholder="Add a new task..." style="flex:1;min-width:200px" maxlength="200">
      <button id="addCard" class="btn btn-primary">Add Task</button>
    </div>

    <div class="kanban" style="margin-top:18px" id="kanban">
      <?php foreach (['todo'=>'TO DO','in_progress'=>'IN PROGRESS','done'=>'DONE'] as $key=>$label): ?>
        <div class="kanban-col" data-col="<?= e($key) ?>">
          <h4><?= e($label) ?></h4>
          <div class="cards-list" style="margin-top:10px">
            <?php foreach ($cols[$key] as $c): ?>
              <div class="kard" data-id="<?= (int)$c['id'] ?>">
                <?= e($c['title']) ?>
                <div class="kard-actions">
                  <?php if ($key !== 'todo'): ?>
                    <button data-move="<?= (int)$c['id'] ?>" data-to="<?= $key === 'done' ? 'in_progress' : 'todo' ?>">←</button>
                  <?php endif; ?>
                  <?php if ($key !== 'done'): ?>
                    <button data-move="<?= (int)$c['id'] ?>" data-to="<?= $key === 'todo' ? 'in_progress' : 'done' ?>">→</button>
                  <?php endif; ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<script>
  // Configuration injected for the JS file
  window.CYBRON_BOARD = { 
    id: <?= (int)$boardId ?>, 
    api: "<?= e(BASE_URL) ?>/api/board-action.php", 
    csrf: "<?= e(csrf_token()) ?>" 
  };
</script>
<script src="<?= e(BASE_URL) ?>/assets/js/board.js"></script>

<?php require __DIR__ . '/includes/footer.php'; ?>